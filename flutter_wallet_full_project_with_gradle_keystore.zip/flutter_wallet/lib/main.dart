import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'providers/wallet_provider.dart';
import 'ui/dashboard_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const ApexWalletApp());
}

class ApexWalletApp extends StatelessWidget {
  const ApexWalletApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => WalletProvider()..initialize()),
      ],
      child: MaterialApp(
        title: 'کیف پول آبتین',
        debugShowCheckedModeBanner: false,
        themeMode: ThemeMode.dark,
        locale: const Locale('fa', 'IR'),
        supportedLocales: const [
          Locale('fa', 'IR'),
          Locale('en', 'US'),
        ],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        darkTheme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF0F121C),
          primaryColor: const Color(0xFF6C5CE7),
          colorScheme: const ColorScheme.dark(
            primary: Color(0xFF6C5CE7),
            secondary: Color(0xFF00CEC9),
            surface: Color(0xFF191D2C),
          ),
          cardColor: const Color(0xFF191D2C),
          fontFamily: 'Vazirmatn',
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF0F121C),
            elevation: 0,
            centerTitle: true,
          ),
        ),
        home: const DashboardScreen(),
      ),
    );
  }
}
