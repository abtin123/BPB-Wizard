import 'dart:convert';
import 'package:http/http.dart' as http;

class RpcService {
  // Public Sepolia / Mainnet RPC endpoints
  static const String ethRpcUrl = 'https://ethereum-sepolia-rpc.publicnode.com';
  static const String btcApiUrl = 'https://blockstream.info/testnet/api';

  static Future<double> getEthBalance(String address) async {
    try {
      final response = await http.post(
        Uri.parse(ethRpcUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'jsonrpc': '2.0',
          'method': 'eth_getBalance',
          'params': [address, 'latest'],
          'id': 1,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['result'] != null) {
          final hexWei = data['result'] as String;
          final wei = BigInt.parse(hexWei.replaceFirst('0x', ''), radix: 16);
          return wei / BigInt.from(10).pow(18);
        }
      }
    } catch (_) {}
    return 0.0;
  }

  static Future<int> getEthNonce(String address) async {
    try {
      final response = await http.post(
        Uri.parse(ethRpcUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'jsonrpc': '2.0',
          'method': 'eth_getTransactionCount',
          'params': [address, 'latest'],
          'id': 1,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['result'] != null) {
          return int.parse((data['result'] as String).replaceFirst('0x', ''), radix: 16);
        }
      }
    } catch (_) {}
    return 0;
  }

  static Future<String> broadcastRawTransaction(String signedTxHex) async {
    try {
      final response = await http.post(
        Uri.parse(ethRpcUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'jsonrpc': '2.0',
          'method': 'eth_sendRawTransaction',
          'params': [signedTxHex],
          'id': 1,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['result'] != null) {
          return data['result'] as String;
        } else if (data['error'] != null) {
          throw Exception(data['error']['message']);
        }
      }
    } catch (e) {
      rethrow;
    }
    throw Exception('Failed to broadcast transaction');
  }

  static Future<double> getBtcBalance(String address) async {
    try {
      final response = await http.get(Uri.parse('$btcApiUrl/address/$address'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final chainStats = data['chain_stats'];
        final funded = chainStats['funded_txo_sum'] as int? ?? 0;
        final spent = chainStats['spent_txo_sum'] as int? ?? 0;
        final satoshis = funded - spent;
        return satoshis / 100000000.0;
      }
    } catch (_) {}
    return 0.0;
  }

  /// Broadcasts a raw Bitcoin transaction (hex) via the configured Esplora-compatible API. Returns the txid.
  static Future<String> broadcastBitcoinTransaction(String rawTxHex) async {
    final response = await http.post(
      Uri.parse('$btcApiUrl/tx'),
      headers: {'Content-Type': 'text/plain'},
      body: rawTxHex,
    );
    if (response.statusCode == 200) {
      return response.body.trim();
    }
    throw Exception('Broadcast failed: ${response.body}');
  }

  /// Fetches confirmed and unconfirmed UTXOs for a Bitcoin address (Esplora API).
  static Future<List<Map<String, dynamic>>> fetchBtcUtxos(String address) async {
    final response = await http.get(Uri.parse('$btcApiUrl/address/$address/utxo'));
    if (response.statusCode != 200) {
      throw Exception('Failed to fetch UTXOs (HTTP ${response.statusCode})');
    }
    final list = jsonDecode(response.body) as List<dynamic>;
    return list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  /// Returns the estimated fee rate in sat/vByte for confirmation within [targetBlocks].
  static Future<double> fetchBtcFeeRate(int targetBlocks) async {
    final response = await http.get(Uri.parse('$btcApiUrl/fee-estimates'));
    if (response.statusCode != 200) {
      throw Exception('Failed to fetch fee estimates (HTTP ${response.statusCode})');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final value = data[targetBlocks.toString()] ?? data['6'] ?? (data.values.isNotEmpty ? data.values.first : null);
    if (value == null) {
      throw Exception('No fee estimate available');
    }
    return (value as num).toDouble();
  }

  /// Number of transactions (confirmed + mempool) touching an address. Zero means it has never been used.
  static Future<int> fetchAddressTxCount(String address) async {
    final response = await http.get(Uri.parse('$btcApiUrl/address/$address'));
    if (response.statusCode != 200) {
      throw Exception('Failed to fetch address info (HTTP ${response.statusCode})');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final chain = data['chain_stats'] as Map<String, dynamic>;
    final mempool = data['mempool_stats'] as Map<String, dynamic>;
    return (chain['tx_count'] as int) + (mempool['tx_count'] as int);
  }
}
