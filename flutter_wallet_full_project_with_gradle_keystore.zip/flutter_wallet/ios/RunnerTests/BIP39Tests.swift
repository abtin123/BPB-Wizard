import XCTest
@testable import Runner

// Official BIP39 test vectors (Trezor python-mnemonic, passphrase "TREZOR").
final class BIP39Tests: XCTestCase {

    func testZeroEntropyVector() throws {
        let entropy = [UInt8](repeating: 0x00, count: 16)
        let words = try BIP39.mnemonic(from: entropy)
        XCTAssertEqual(words.joined(separator: " "),
                       "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about")
        let seed = try BIP39.seed(from: words, passphrase: "TREZOR")
        XCTAssertEqual(seed.hex(),
                       "c55257c360c07c72029aebc1b53c05ed0362ada38ead3e3e9efa3708e53495531f09a6987599d18264c1e1c92f2cf141630c7a3c4ab7c81b2f001698e7463b04")
    }

    func testSevenFVector() throws {
        let entropy = [UInt8](repeating: 0x7f, count: 16)
        let words = try BIP39.mnemonic(from: entropy)
        XCTAssertEqual(words.joined(separator: " "),
                       "legal winner thank year wave sausage worth useful legal winner thank yellow")
    }

    func testRoundTripEntropy() throws {
        let entropy: [UInt8] = (0..<32).map { UInt8($0 * 7 % 256) }
        let words = try BIP39.mnemonic(from: entropy)
        XCTAssertEqual(words.count, 24)
        XCTAssertEqual(try BIP39.entropy(from: words), entropy)
    }

    func testBadChecksumIsRejected() throws {
        let words = try BIP39.mnemonic(from: [UInt8](repeating: 0x00, count: 16))
        var broken = words
        broken[11] = "abandon"
        XCTAssertThrowsError(try BIP39.entropy(from: broken))
    }

    func testUnknownWordIsRejected() {
        XCTAssertThrowsError(try BIP39.entropy(from: Array(repeating: "notaword", count: 12)))
    }
}

private extension Array where Element == UInt8 {
    func hex() -> String { map { String(format: "%02x", $0) }.joined() }
}
