"""Verifies the BIP39 wordlist and vectors shipped in the iOS Swift source.

Runs with the standard library only, so it works in any CI runner.
Exits non-zero on the first failed check.
"""
import hashlib
import re
import sys
from pathlib import Path

SWIFT_FILE = Path(__file__).resolve().parent.parent / "ios/Runner/Core/BIP39.swift"


def load_wordlist() -> list[str]:
    text = SWIFT_FILE.read_text(encoding="utf-8")
    block = re.search(r"static let wordlist: \[String\] = \[(.*?)\]", text, re.S)
    if not block:
        raise SystemExit("wordlist block not found in BIP39.swift")
    return re.findall(r'"([a-z]+)"', block.group(1))


def mnemonic(entropy: bytes, words: list[str]) -> str:
    cs_bits = len(entropy) * 8 // 32
    h = hashlib.sha256(entropy).digest()
    bits = "".join(f"{b:08b}" for b in entropy) + f"{h[0]:08b}"[:cs_bits]
    return " ".join(words[int(bits[i:i + 11], 2)] for i in range(0, len(bits), 11))


def seed(phrase: str, passphrase: str = "") -> str:
    return hashlib.pbkdf2_hmac(
        "sha512", phrase.encode(), ("mnemonic" + passphrase).encode(), 2048, 64
    ).hex()


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
    if not ok:
        sys.exit(1)


def main() -> None:
    words = load_wordlist()
    check("wordlist has 2048 entries", len(words) == 2048)
    check("wordlist entries are unique", len(set(words)) == 2048)
    check("wordlist is sorted", words == sorted(words))
    check("first word is abandon", words[0] == "abandon")
    check("last word is zoo", words[-1] == "zoo")

    zero = bytes(16)
    m0 = mnemonic(zero, words)
    check(
        "zero entropy mnemonic",
        m0 == "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about",
    )
    check(
        "zero entropy seed (TREZOR)",
        seed(m0, "TREZOR")
        == "c55257c360c07c72029aebc1b53c05ed0362ada38ead3e3e9efa3708e53495531f09a6987599d18264c1e1c92f2cf141630c7a3c4ab7c81b2f001698e7463b04",
    )
    check(
        "0x7f entropy mnemonic",
        mnemonic(bytes([0x7F] * 16), words)
        == "legal winner thank year wave sausage worth useful legal winner thank yellow",
    )
    print("All BIP39 checks passed.")


if __name__ == "__main__":
    main()
