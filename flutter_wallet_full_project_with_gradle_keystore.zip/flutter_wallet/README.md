# Apex Non-Custodial Multi-Chain Crypto Wallet (Flutter + Native Kotlin Core)

## Architecture Overview
1. **Android Native Kotlin Core (`WalletCore.kt`)**:
   - Cryptographically secure 128-bit entropy generation and standard BIP39 mnemonic translation.
   - Master seed derivation using PBKDF2 with HMAC-SHA512.
   - BIP44 EVM derivation (`m/44'/60'/0'/0/0`) & Keccak-256 for Ethereum addresses.
   - BIP84 Native SegWit derivation (`m/84'/0'/0'/0/0`) with SHA-256, RIPEMD-160, and Bech32 encoding.
   - Hardware-backed Android KeyStore AES-256-GCM encryption of entropy.
   - Raw transaction signing: RLP encoding & canonical EIP-2 ECDSA secp256k1 signatures for Ethereum, DER signatures for Bitcoin.
2. **MethodChannel Bridge (`MainActivity.kt`)**:
   - Zero-leakage key architecture: Private keys remain isolated inside Kotlin native memory.
3. **Flutter Dart Layer (`lib/`)**:
   - State management via `Provider`.
   - Live RPC queries for Sepolia & Bitcoin Testnet.
   - Native QR Code scanner and generator.

## How to Run:
```bash
flutter pub get
flutter run
```
