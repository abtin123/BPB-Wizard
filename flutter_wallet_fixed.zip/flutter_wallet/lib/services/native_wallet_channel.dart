import 'package:flutter/services.dart';

class NativeWalletChannel {
  static const MethodChannel _channel = MethodChannel('com.wallet.noncustodial/core');

  static Future<Map<String, dynamic>> generateNewWallet() async {
    final result = await _channel.invokeMethod<Map<dynamic, dynamic>>('generateNewWallet');
    return Map<String, dynamic>.from(result ?? {});
  }

  static Future<Map<String, dynamic>?> getStoredAddresses() async {
    final result = await _channel.invokeMethod<Map<dynamic, dynamic>>('getStoredAddresses');
    if (result == null) return null;
    return Map<String, dynamic>.from(result);
  }

  static Future<List<String>> getMnemonicWords() async {
    final result = await _channel.invokeMethod<List<dynamic>>('getMnemonicWords');
    return result?.map((e) => e.toString()).toList() ?? [];
  }

  static Future<String> signEthereumTx({
    required int nonce,
    required String gasPriceWei,
    required String gasLimit,
    required String to,
    required String valueWei,
    required String data,
    required int chainId,
  }) async {
    final result = await _channel.invokeMethod<String>('signEthereumTx', {
      'nonce': nonce,
      'gasPrice': gasPriceWei,
      'gasLimit': gasLimit,
      'to': to,
      'value': valueWei,
      'data': data,
      'chainId': chainId,
    });
    return result ?? '';
  }

  static Future<String> signBitcoinTx({
    required String txHex,
    required int vout,
  }) async {
    final result = await _channel.invokeMethod<String>('signBitcoinTx', {
      'txHex': txHex,
      'vout': vout,
    });
    return result ?? '';
  }
}
