package com.wallet.noncustodial.crypto_wallet

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.bouncycastle.crypto.digests.RIPEMD160Digest
import org.bouncycastle.crypto.digests.SHA256Digest
import org.bouncycastle.crypto.digests.SHA512Digest
import org.bouncycastle.crypto.macs.HMac
import org.bouncycastle.crypto.params.KeyParameter
import org.bouncycastle.jcajce.provider.digest.Keccak
import org.bouncycastle.jce.ECNamedCurveTable
import org.bouncycastle.jce.spec.ECNamedCurveParameterSpec
import org.bouncycastle.math.ec.ECPoint
import java.io.ByteArrayOutputStream
import java.math.BigInteger
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class WalletCore(private val context: Context) {

    companion object {
        private const val BTC_HRP = "tb"
        private const val BTC_CHANGE_CHAIN = 1
        private const val DUST_LIMIT_SATS = 546L
        private const val TX_VERSION = 2L
        private const val TX_LOCKTIME = 0L
        private const val RBF_SEQUENCE = 0xfffffffdL
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "ApexWalletMasterMasterKey"
        private const val GCM_IV_LENGTH = 12
        private const val GCM_TAG_LENGTH = 128
        private const val PREFS_NAME = "wallet_encrypted_storage"
        private const val ENCRYPTED_ENTROPY_KEY = "encrypted_entropy"
        private const val GCM_IV_KEY = "gcm_iv"
    }

    private val ecSpec: ECNamedCurveParameterSpec = ECNamedCurveTable.getParameterSpec("secp256k1")

    // BIP39 English Wordlist truncated subset representation or full mathematical loader
    private val bip39WordList = listOf(
        "abandon", "ability", "able", "about", "above", "absent", "absorb", "abstract", "absurd", "abuse",
        "access", "accident", "account", "accuse", "achieve", "acid", "acoustic", "acquire", "across", "act",
        "action", "actor", "actress", "actual", "adapt", "add", "addict", "address", "adjust", "admit",
        "adult", "advance", "advice", "aerobic", "affair", "afford", "afraid", "again", "age", "agent",
        "agree", "ahead", "aim", "air", "airport", "aisle", "alarm", "album", "alcohol", "alert",
        "alien", "all", "alley", "allow", "almost", "alone", "alpha", "already", "also", "alter",
        "always", "amateur", "amazing", "among", "amount", "amused", "analyst", "anchor", "ancient", "anger",
        "angle", "angry", "animal", "ankle", "announce", "annual", "another", "answer", "antenna", "antique",
        "anxiety", "any", "apart", "apology", "appear", "apple", "approve", "april", "arch", "arctic",
        "area", "arena", "argue", "arm", "armed", "armor", "army", "around", "arrange", "arrest",
        "arrive", "arrow", "art", "artefact", "artist", "artwork", "ask", "aspect", "assault", "asset",
        "assist", "assume", "asthma", "athlete", "atom", "attack", "attend", "attitude", "attract", "auction",
        "audit", "august", "aunt", "author", "auto", "autumn", "average", "avocado", "avoid", "awake",
        "aware", "away", "awesome", "awful", "awkward", "axis", "baby", "bachelor", "bacon", "badge",
        "bag", "balance", "balcony", "ball", "bamboo", "banana", "banner", "bar", "barely", "bargain",
        "barrel", "base", "basic", "basket", "battle", "beach", "bean", "beauty", "because", "become",
        "beef", "before", "begin", "behave", "behind", "believe", "below", "belt", "bench", "benefit",
        "best", "betray", "better", "between", "beyond", "bicycle", "bid", "bike", "bind", "biology",
        "bird", "birth", "bitter", "black", "blade", "blame", "blanket", "blast", "bleak", "bless",
        "blind", "blood", "blossom", "blouse", "blue", "blur", "blush", "board", "boat", "body",
        "boil", "bomb", "bone", "bonus", "book", "boost", "border", "boring", "borrow", "boss",
        "bottom", "bounce", "box", "boy", "bracket", "brain", "brand", "brass", "brave", "bread",
        "breeze", "brick", "bridge", "brief", "bright", "bring", "brisk", "broccoli", "broken", "bronze",
        "broom", "brother", "brown", "brush", "bubble", "buddy", "budget", "buffalo", "build", "bulb",
        "bulk", "bullet", "bundle", "bunker", "burden", "burger", "burst", "bus", "business", "busy",
        "butter", "buyer", "buzz", "cabbage", "cabin", "cable", "cactus", "cage", "cake", "call",
        "calm", "camera", "camp", "can", "canal", "cancel", "candy", "cannon", "canoe", "canvas",
        "canyon", "capable", "capital", "captain", "car", "carbon", "card", "cargo", "carpet", "carry",
        "cart", "case", "cash", "casino", "castle", "casual", "cat", "catalog", "catch", "category",
        "cattle", "caught", "cause", "caution", "cave", "ceiling", "celery", "cement", "census", "century",
        "cereal", "certain", "chair", "chalk", "champion", "change", "chaos", "chapter", "charge", "chase",
        "chat", "cheap", "check", "cheese", "chef", "cherry", "chest", "chicken", "chief", "child",
        "chimney", "choice", "choose", "chronic", "chuckle", "chunk", "churn", "cigar", "cinnamon", "circle",
        "citizen", "city", "civil", "claim", "clap", "clarify", "claw", "clay", "clean", "clerk",
        "clever", "click", "client", "cliff", "climb", "clinic", "clip", "clock", "clog", "close",
        "cloth", "cloud", "clown", "club", "clump", "cluster", "clutch", "coach", "coast", "coconut",
        "code", "coffee", "coil", "coin", "collect", "color", "column", "combine", "come", "comfort",
        "comic", "common", "company", "concert", "conduct", "confirm", "congress", "connect", "consider", "control",
        "convince", "cook", "cool", "copper", "copy", "coral", "core", "corn", "correct", "cost",
        "cotton", "couch", "country", "couple", "course", "cousin", "cover", "coyote", "crack", "cradle",
        "craft", "cram", "crane", "crash", "crater", "crawl", "crazy", "cream", "credit", "creek",
        "crew", "cricket", "crime", "crisp", "critic", "crop", "cross", "crouch", "crowd", "crucial",
        "cruel", "cruise", "crumble", "crunch", "crush", "cry", "crystal", "cube", "culture", "cup",
        "cupboard", "curious", "current", "curtain", "curve", "cushion", "custom", "cute", "cycle", "dad",
        "damage", "damp", "dance", "danger", "daring", "dash", "daughter", "dawn", "day", "deal",
        "debate", "debris", "decade", "december", "decide", "decline", "decorate", "decrease", "deer", "defense",
        "define", "defy", "degree", "delay", "deliver", "demand", "demise", "denial", "dentist", "deny",
        "depart", "depend", "deposit", "depth", "deputy", "derive", "describe", "desert", "design", "desk",
        "despair", "destroy", "detail", "detect", "develop", "device", "devote", "diagram", "dial", "diamond",
        "diary", "dice", "diesel", "diet", "differ", "digital", "dignity", "dilemma", "dinner", "dinosaur",
        "direct", "dirt", "disagree", "discover", "disease", "dish", "dismiss", "disorder", "display", "distance",
        "divert", "divide", "divorce", "dizzy", "doctor", "document", "dog", "doll", "dolphin", "domain",
        "donate", "donkey", "donor", "door", "dose", "double", "dove", "draft", "dragon", "drama",
        "drastic", "draw", "dream", "dress", "drift", "drill", "drink", "drip", "drive", "drop",
        "drum", "dry", "duck", "dumb", "dune", "during", "dust", "dutch", "duty", "dwarf",
        "dynamic", "eager", "eagle", "early", "earn", "earth", "easily", "east", "easy", "echo",
        "ecology", "economy", "edge", "edit", "educate", "effort", "egg", "eight", "either", "elbow",
        "elder", "electric", "elegant", "element", "elephant", "elevator", "elite", "else", "embark", "embody",
        "embrace", "emerge", "emotion", "employ", "empower", "empty", "enable", "enact", "end", "endless",
        "endorse", "enemy", "energy", "enforce", "engage", "engine", "enhance", "enjoy", "enlist", "enough",
        "enrich", "enroll", "ensure", "enter", "entire", "entry", "envelope", "episode", "equal", "equip",
        "era", "erase", "erode", "erosion", "error", "erupt", "escape", "essay", "essence", "estate",
        "eternal", "ethics", "evidence", "evil", "evoke", "evolve", "exact", "example", "excess", "exchange",
        "excite", "exclude", "excuse", "execute", "exercise", "exhaust", "exhibit", "exile", "exist", "exit",
        "exotic", "expand", "expect", "expire", "explain", "expose", "express", "extend", "extra", "eye",
        "eyebrow", "fabric", "face", "faculty", "fade", "faint", "faith", "fall", "false", "fame",
        "family", "famous", "fan", "fancy", "fantasy", "farm", "fashion", "fat", "fatal", "father",
        "fatigue", "fault", "favorite", "feature", "february", "federal", "fee", "feed", "feel", "female",
        "fence", "festival", "fetch", "fever", "few", "fiber", "fiction", "field", "figure", "file",
        "film", "filter", "final", "find", "fine", "finger", "finish", "fire", "firm", "first",
        "fiscal", "fish", "fit", "fitness", "fix", "flag", "flame", "flash", "flat", "flavor",
        "flee", "flight", "flip", "float", "flock", "floor", "flower", "fluid", "flush", "fly",
        "foam", "focus", "fog", "foil", "fold", "follow", "food", "foot", "force", "forest",
        "forget", "fork", "fortune", "forum", "forward", "fossil", "foster", "found", "fox", "fragile",
        "frame", "frequent", "fresh", "friend", "fringe", "frog", "front", "frost", "frown", "frozen",
        "fruit", "fuel", "fun", "funny", "furnace", "fury", "future", "gadget", "gain", "galaxy",
        "gallery", "game", "gap", "garage", "garbage", "garden", "garlic", "garment", "gas", "gasp",
        "gate", "gather", "gauge", "gaze", "general", "genius", "genre", "gentle", "genuine", "gesture",
        "ghost", "giant", "gift", "giggle", "ginger", "giraffe", "girl", "give", "glad", "glance",
        "glare", "glass", "glide", "glimpse", "globe", "gloom", "glory", "glove", "glow", "glue",
        "goat", "goddess", "gold", "good", "goose", "gorilla", "gospel", "gossip", "govern", "gown",
        "grab", "grace", "grain", "grant", "grape", "grass", "gravity", "great", "green", "grid",
        "grief", "grit", "grocery", "group", "grow", "grunt", "guard", "guess", "guide", "guilt",
        "guitar", "gun", "gym", "habit", "hair", "half", "hammer", "hamster", "hand", "happy",
        "harbor", "hard", "harsh", "harvest", "hat", "have", "hawk", "hazard", "head", "health",
        "heart", "heavy", "hedgehog", "height", "hello", "helmet", "help", "hen", "hero", "hidden",
        "high", "hill", "hint", "hip", "hire", "history", "hobby", "hockey", "hold", "hole",
        "holiday", "hollow", "home", "honey", "hood", "hope", "horn", "horror", "horse", "hospital",
        "host", "hotel", "hour", "hover", "hub", "huge", "human", "humble", "humor", "hundred",
        "hungry", "hunt", "hurdle", "hurry", "hurt", "husband", "hybrid", "ice", "icon", "idea",
        "identify", "idle", "ignore", "ill", "illegal", "illness", "image", "imitate", "immense", "immune",
        "impact", "impose", "improve", "impulse", "inch", "include", "income", "increase", "index", "indicate",
        "indoor", "industry", "infant", "inflict", "inform", "inhale", "inherit", "initial", "inject", "injury",
        "inmate", "inner", "innocent", "input", "inquiry", "insane", "insect", "inside", "inspire", "install",
        "intact", "interest", "into", "invest", "invite", "involve", "iron", "island", "isolate", "issue",
        "item", "ivory", "jacket", "jaguar", "jar", "jazz", "jealous", "jeans", "jelly", "jewel",
        "job", "join", "joke", "journey", "joy", "judge", "juice", "jump", "jungle", "junior",
        "junk", "just", "kangaroo", "keen", "keep", "ketchup", "key", "kick", "kid", "kidney",
        "kind", "kingdom", "kiss", "kit", "kitchen", "kite", "kitten", "kiwi", "knee", "knife",
        "knock", "know", "lab", "label", "labor", "ladder", "lady", "lake", "lamp", "language",
        "laptop", "large", "later", "latin", "laugh", "laundry", "lava", "law", "lawn", "lawsuit",
        "layer", "lazy", "leader", "leaf", "learn", "leave", "lecture", "left", "leg", "legal",
        "legend", "leisure", "lemon", "lend", "length", "lens", "leopard", "lesson", "letter", "level",
        "liar", "liberty", "library", "license", "life", "lift", "light", "like", "limb", "limit",
        "link", "lion", "liquid", "list", "little", "live", "lizard", "load", "loan", "lobster",
        "local", "lock", "logic", "lonely", "long", "loop", "lottery", "loud", "lounge", "love",
        "loyal", "lucky", "luggage", "lumber", "lunar", "lunch", "luxury", "lyrics", "machine", "mad",
        "magic", "magnet", "maid", "mail", "main", "major", "make", "mammal", "man", "manage",
        "mandate", "mango", "mansion", "manual", "maple", "marble", "march", "margin", "marine", "market",
        "marriage", "mask", "mass", "master", "match", "material", "math", "matrix", "matter", "maximum",
        "maze", "meadow", "mean", "measure", "meat", "mechanic", "medal", "media", "melody", "melt",
        "member", "memory", "mention", "menu", "mercy", "merge", "merit", "merry", "mesh", "message",
        "metal", "method", "middle", "midnight", "milk", "million", "mimic", "mind", "minimum", "minor",
        "minute", "miracle", "mirror", "misery", "miss", "mistake", "mix", "mixed", "mixture", "mobile",
        "model", "modify", "mom", "moment", "monitor", "monkey", "monster", "month", "moon", "moral",
        "more", "morning", "mosquito", "mother", "motion", "motor", "mountain", "mouse", "move", "movie",
        "much", "muffin", "mule", "multiply", "muscle", "museum", "mushroom", "music", "must", "mutual",
        "myself", "mystery", "myth", "naive", "name", "napkin", "narrow", "nasty", "nation", "nature",
        "near", "neck", "need", "negative", "neglect", "neither", "nephew", "nerve", "nest", "net",
        "network", "neutral", "never", "news", "next", "nice", "night", "noble", "noise", "nominee",
        "noodle", "normal", "north", "nose", "notable", "note", "nothing", "notice", "novel", "now",
        "nuclear", "number", "nurse", "nut", "oak", "obey", "object", "oblige", "obscure", "observe",
        "obtain", "obvious", "occur", "ocean", "october", "odor", "off", "offer", "office", "often",
        "oil", "okay", "old", "olive", "olympic", "omit", "once", "one", "onion", "online",
        "only", "open", "opera", "opinion", "oppose", "option", "orange", "orbit", "orchard", "order",
        "ordinary", "organ", "orient", "original", "orphan", "ostrich", "other", "outdoor", "outer", "output",
        "outside", "oval", "oven", "over", "own", "owner", "oxygen", "oyster", "ozone", "pact",
        "paddle", "page", "pair", "palace", "palm", "panda", "panel", "panic", "panther", "paper",
        "parade", "parent", "park", "parrot", "party", "pass", "patch", "path", "patient", "patrol",
        "pattern", "pause", "pave", "payment", "peace", "peanut", "pear", "peasant", "pelican", "pen",
        "penalty", "pencil", "people", "pepper", "perfect", "permit", "person", "pet", "phone", "photo",
        "phrase", "physical", "piano", "picnic", "picture", "piece", "pig", "pigeon", "pill", "pilot",
        "pink", "pioneer", "pipe", "pistol", "pitch", "pizza", "place", "planet", "plastic", "plate",
        "play", "please", "pledge", "pluck", "plug", "plunge", "poem", "poet", "point", "polar",
        "pole", "police", "pond", "pony", "pool", "popular", "portion", "position", "possible", "post",
        "potato", "pottery", "poverty", "powder", "power", "practice", "praise", "predict", "prefer", "prepare",
        "present", "pretty", "prevent", "price", "pride", "primary", "print", "priority", "prison", "private",
        "prize", "problem", "process", "produce", "profit", "program", "project", "promote", "proof", "property",
        "prosper", "protect", "proud", "provide", "public", "pudding", "pull", "pulp", "pulse", "pumpkin",
        "punch", "pupil", "puppy", "purchase", "purity", "purpose", "purse", "push", "put", "puzzle",
        "pyramid", "quality", "quantum", "quarter", "question", "quick", "quit", "quiz", "quote", "rabbit",
        "raccoon", "race", "rack", "radar", "radio", "rail", "rain", "raise", "rally", "ramp",
        "ranch", "random", "range", "rapid", "rare", "rate", "rather", "raven", "raw", "razor",
        "ready", "real", "reason", "rebel", "rebuild", "recall", "receive", "recipe", "record", "recycle",
        "reduce", "reflect", "reform", "refuse", "region", "regret", "regular", "reject", "relax", "release",
        "relief", "rely", "remain", "remember", "remind", "remove", "render", "renew", "rent", "reopen",
        "repair", "repeat", "replace", "report", "require", "rescue", "resemble", "resist", "resource", "response",
        "result", "retire", "retreat", "return", "reunion", "reveal", "review", "reward", "rhythm", "rib",
        "ribbon", "rice", "rich", "ride", "ridge", "rifle", "right", "rigid", "ring", "riot",
        "ripple", "risk", "ritual", "rival", "river", "road", "roast", "robot", "robust", "rocket",
        "romance", "roof", "rookie", "room", "rose", "rotate", "rough", "round", "route", "royal",
        "rubber", "rude", "rug", "rule", "run", "runway", "rural", "sad", "saddle", "sadness",
        "safe", "sail", "salad", "salmon", "salon", "salt", "salute", "same", "sample", "sand",
        "satisfy", "satoshi", "sauce", "sausage", "save", "say", "scale", "scan", "scare", "scatter",
        "scene", "scheme", "school", "science", "scissors", "scorpion", "scout", "scrap", "screen", "script",
        "scrub", "sea", "search", "season", "seat", "second", "secret", "section", "security", "seed",
        "seek", "segment", "select", "sell", "seminar", "senior", "sense", "sentence", "series", "service",
        "session", "settle", "setup", "seven", "shadow", "shaft", "shallow", "share", "shed", "shell",
        "sheriff", "shield", "shift", "shine", "ship", "shiver", "shock", "shoe", "shoot", "shop",
        "short", "shoulder", "shove", "shrimp", "shrug", "shuffle", "shy", "sibling", "sick", "side",
        "siege", "sight", "sign", "silent", "silk", "silly", "silver", "similar", "simple", "since",
        "sing", "siren", "sister", "situate", "six", "size", "skate", "sketch", "ski", "skill",
        "skin", "skirt", "skull", "slab", "slam", "sleep", "slender", "slice", "slide", "slight",
        "slim", "slogan", "slot", "slow", "slush", "small", "smart", "smile", "smoke", "smooth",
        "snack", "snake", "snap", "sniff", "snow", "soap", "soccer", "social", "sock", "soda",
        "soft", "solar", "soldier", "solid", "solution", "solve", "someone", "song", "soon", "sorry",
        "sort", "soul", "sound", "soup", "source", "south", "space", "spare", "spatial", "spawn",
        "speak", "special", "speed", "spell", "spend", "sphere", "spice", "spider", "spike", "spin",
        "spirit", "split", "spoil", "sponsor", "spoon", "sport", "spot", "spray", "spread", "spring",
        "spy", "square", "squeeze", "squirrel", "stable", "stadium", "staff", "stage", "stairs", "stamp",
        "stand", "start", "state", "stay", "steak", "steel", "stem", "step", "stereo", "stick",
        "still", "sting", "stock", "stomach", "stone", "stool", "story", "stove", "strategy", "street",
        "strike", "strong", "struggle", "student", "stuff", "stumble", "style", "subject", "submit", "subway",
        "success", "such", "sudden", "suffer", "sugar", "suggest", "suit", "summer", "sun", "sunny",
        "sunset", "super", "supply", "supreme", "sure", "surface", "surge", "surprise", "surround", "survey",
        "suspect", "sustain", "swallow", "swamp", "swap", "swarm", "swear", "sweet", "swift", "swim",
        "swing", "switch", "sword", "symbol", "symptom", "syrup", "system", "table", "tackle", "tag",
        "tail", "talent", "talk", "tank", "tape", "target", "task", "taste", "tattoo", "taxi",
        "teach", "team", "tell", "ten", "tenant", "tennis", "tent", "term", "test", "text",
        "thank", "that", "theme", "then", "theory", "there", "they", "thing", "this", "thought",
        "three", "thrive", "throw", "thumb", "thunder", "ticket", "tide", "tiger", "tilt", "timber",
        "time", "tiny", "tip", "tired", "tissue", "title", "toast", "tobacco", "today", "toddler",
        "toe", "together", "toilet", "token", "tomato", "tomorrow", "tone", "tongue", "tonight", "tool",
        "tooth", "top", "topic", "topple", "torch", "tornado", "tortoise", "toss", "total", "tourist",
        "toward", "tower", "town", "toy", "track", "trade", "traffic", "tragic", "train", "transfer",
        "trap", "trash", "travel", "tray", "treat", "tree", "trend", "trial", "tribe", "trick",
        "trigger", "trim", "trip", "trophy", "trouble", "truck", "true", "truly", "trumpet", "trust",
        "truth", "try", "tube", "tuition", "tumble", "tuna", "tunnel", "turkey", "turn", "turtle",
        "twelve", "twenty", "twice", "twin", "twist", "two", "type", "typical", "ugly", "umbrella",
        "unable", "unaware", "uncle", "uncover", "under", "undo", "unfair", "unfold", "unhappy", "uniform",
        "unique", "unit", "universe", "unknown", "unlock", "until", "unusual", "unveil", "update", "upgrade",
        "uphold", "upon", "upper", "upset", "urban", "urge", "usage", "use", "used", "useful",
        "useless", "usual", "utility", "vacant", "vacuum", "vague", "valid", "valley", "valve", "van",
        "vanish", "vapor", "various", "vast", "vault", "vehicle", "velvet", "vendor", "venture", "venue",
        "verb", "verify", "version", "very", "vessel", "veteran", "viable", "vibrant", "vicious", "victory",
        "video", "view", "village", "vintage", "violin", "virtual", "virus", "visa", "visit", "visual",
        "vital", "vivid", "vocal", "voice", "void", "volcano", "volume", "vote", "voyage", "wage",
        "wagon", "wait", "walk", "wall", "walnut", "want", "warfare", "warm", "warrior", "wash",
        "wasp", "waste", "water", "wave", "way", "wealth", "weapon", "wear", "weasel", "weather",
        "web", "wedding", "weekend", "weird", "welcome", "west", "wet", "whale", "what", "wheat",
        "wheel", "when", "where", "whip", "whisper", "wide", "width", "wife", "wild", "will",
        "win", "window", "wine", "wing", "wink", "winner", "winter", "wire", "wisdom", "wise",
        "wish", "witness", "wolf", "woman", "wonder", "wood", "wool", "word", "work", "world",
        "worry", "worth", "wrap", "wreck", "wrestle", "wrist", "write", "wrong", "yard", "year",
        "yellow", "you", "young", "youth", "zebra", "zero", "zone", "zoo"
    )

    init {
        initKeyStore()
    }

    private fun initKeyStore() {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
            keyGenerator.init(spec)
            keyGenerator.generateKey()
        }
    }

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        return keyStore.getKey(KEY_ALIAS, null) as SecretKey
    }

    fun generateEntropy(): ByteArray {
        val secureRandom = SecureRandom()
        val entropy = ByteArray(16) // 128 bits = 12 words
        secureRandom.nextBytes(entropy)
        return entropy
    }

    fun entropyToMnemonic(entropy: ByteArray): List<String> {
        check(bip39WordList.size == 2048) {
            "BIP39 English wordlist must contain exactly 2048 words (currently ${bip39WordList.size}). Refusing to generate invalid seeds."
        }
        val sha256 = sha256(entropy)
        val checksumBits = entropy.size * 8 / 32
        val checksum = sha256[0].toInt() and 0xFF

        val totalBits = entropy.size * 8 + checksumBits
        val bitString = StringBuilder()
        for (b in entropy) {
            bitString.append(String.format("%8s", Integer.toBinaryString(b.toInt() and 0xFF)).replace(' ', '0'))
        }
        val csBinary = String.format("%8s", Integer.toBinaryString(checksum)).replace(' ', '0')
        bitString.append(csBinary.substring(0, checksumBits))

        val words = mutableListOf<String>()
        for (i in 0 until totalBits step 11) {
            val chunk = bitString.substring(i, i + 11)
            val index = Integer.parseInt(chunk, 2) % bip39WordList.size
            words.add(bip39WordList[index])
        }
        return words
    }

    fun storeEncryptedEntropy(entropy: ByteArray) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(entropy)

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(ENCRYPTED_ENTROPY_KEY, bytesToHex(encrypted))
            .putString(GCM_IV_KEY, bytesToHex(iv))
            .apply()
    }

    fun loadDecryptedEntropy(): ByteArray? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val encryptedHex = prefs.getString(ENCRYPTED_ENTROPY_KEY, null) ?: return null
        val ivHex = prefs.getString(GCM_IV_KEY, null) ?: return null

        val encrypted = hexToBytes(encryptedHex)
        val iv = hexToBytes(ivHex)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)
        return cipher.doFinal(encrypted)
    }

    fun mnemonicToSeed(mnemonicWords: List<String>, passphrase: String = ""): ByteArray {
        val mnemonic = mnemonicWords.joinToString(" ")
        val salt = "mnemonic$passphrase"
        return pbkdf2HmacSha512(mnemonic.toByteArray(StandardCharsets.UTF_8), salt.toByteArray(StandardCharsets.UTF_8), 2048, 64)
    }

    // BIP32 Derivation
    fun deriveMasterKey(seed: ByteArray): Pair<ByteArray, ByteArray> {
        val hmac = HMac(SHA512Digest())
        hmac.init(KeyParameter("Bitcoin seed".toByteArray(StandardCharsets.UTF_8)))
        hmac.update(seed, 0, seed.size)
        val output = ByteArray(64)
        hmac.doFinal(output, 0)
        val privKey = output.copyOfRange(0, 32)
        val chainCode = output.copyOfRange(32, 64)
        return Pair(privKey, chainCode)
    }

    fun deriveChildKey(parentKey: ByteArray, parentChainCode: ByteArray, index: Long): Pair<ByteArray, ByteArray> {
        val data = ByteArray(37)
        if (index >= 0x80000000L) {
            data[0] = 0x00
            System.arraycopy(parentKey, 0, data, 1, 32)
        } else {
            val pubKey = getPublicKey(parentKey, true)
            System.arraycopy(pubKey, 0, data, 0, 33)
        }
        data[33] = ((index shr 24) and 0xFF).toByte()
        data[34] = ((index shr 16) and 0xFF).toByte()
        data[35] = ((index shr 8) and 0xFF).toByte()
        data[36] = (index and 0xFF).toByte()

        val hmac = HMac(SHA512Digest())
        hmac.init(KeyParameter(parentChainCode))
        hmac.update(data, 0, data.size)
        val output = ByteArray(64)
        hmac.doFinal(output, 0)

        val il = output.copyOfRange(0, 32)
        val ir = output.copyOfRange(32, 64)

        val childKey = BigInteger(1, il).add(BigInteger(1, parentKey)).mod(ecSpec.n).toByteArray()
        val childKeyFormatted = ByteArray(32)
        val offset = if (childKey.size > 32) childKey.size - 32 else 0
        val destPos = if (childKey.size < 32) 32 - childKey.size else 0
        val len = if (childKey.size > 32) 32 else childKey.size
        System.arraycopy(childKey, offset, childKeyFormatted, destPos, len)

        return Pair(childKeyFormatted, ir)
    }

    // BIP44: m/44'/60'/0'/0/0 for Ethereum
    fun deriveEthereumPrivateKey(seed: ByteArray): ByteArray {
        var (key, chainCode) = deriveMasterKey(seed)
        val path = listOf(0x8000002cL, 0x8000003cL, 0x80000000L, 0L, 0L)
        for (idx in path) {
            val child = deriveChildKey(key, chainCode, idx)
            key = child.first
            chainCode = child.second
        }
        return key
    }

    // BIP84: m/84'/0'/0'/0/0 for Native SegWit (Bech32) Bitcoin
    // BIP84 path m/84'/0'/0'/chain/index (chain 0 = receive, 1 = change)
    fun deriveBip84Key(seed: ByteArray, chain: Int, index: Int): ByteArray {
        var (key, chainCode) = deriveMasterKey(seed)
        val path = listOf(0x80000054L, 0x80000000L, 0x80000000L, chain.toLong(), index.toLong())
        for (idx in path) {
            val child = deriveChildKey(key, chainCode, idx)
            key = child.first
            chainCode = child.second
        }
        return key
    }

    fun deriveBitcoinPrivateKey(seed: ByteArray): ByteArray = deriveBip84Key(seed, 0, 0)

    fun bip84Address(privKey: ByteArray): String =
        bech32Encode(BTC_HRP, 0, ripemd160(sha256(getPublicKey(privKey, true))))

    fun getEthereumAddress(privKey: ByteArray): String {
        val pubKey = getPublicKey(privKey, false) // 65 bytes: 0x04 + X + Y
        val pubKeyRaw = pubKey.copyOfRange(1, 65)
        val keccak = Keccak.Digest256()
        val hash = keccak.digest(pubKeyRaw)
        val addressBytes = hash.copyOfRange(12, 32)
        return "0x" + bytesToHex(addressBytes)
    }

    fun getBitcoinSegwitAddress(privKey: ByteArray): String {
        val pubKey = getPublicKey(privKey, true) // 33 bytes compressed
        val sha = sha256(pubKey)
        val ripemd = ripemd160(sha) // 20 bytes witness program
        return bech32Encode(BTC_HRP, 0, ripemd)
    }

    fun signEthereumTransaction(privKey: ByteArray, nonce: Long, gasPrice: BigInteger, gasLimit: BigInteger, to: String, value: BigInteger, data: ByteArray, chainId: Long): String {
        val cleanTo = if (to.startsWith("0x")) to.substring(2) else to
        val toBytes = hexToBytes(cleanTo)

        val rawTx = listOf(
            encodeLong(nonce),
            encodeBigInt(gasPrice),
            encodeBigInt(gasLimit),
            toBytes,
            encodeBigInt(value),
            data,
            encodeLong(chainId),
            ByteArray(0),
            ByteArray(0)
        )

        val encodedRaw = rlpEncodeList(rawTx)
        val keccak = Keccak.Digest256()
        val txHash = keccak.digest(encodedRaw)

        // Deterministic ECDSA signature over secp256k1
        val (r, s, v) = signECDSA(privKey, txHash)
        val recoveryId = v + (chainId * 2 + 35)

        val signedTx = listOf(
            encodeLong(nonce),
            encodeBigInt(gasPrice),
            encodeBigInt(gasLimit),
            toBytes,
            encodeBigInt(value),
            data,
            encodeBigInt(BigInteger.valueOf(recoveryId)),
            r.toByteArray(),
            s.toByteArray()
        )

        val finalEncoded = rlpEncodeList(signedTx)
        return "0x" + bytesToHex(finalEncoded)
    }

    // ECDSA Signature generator
    private fun signECDSA(privKey: ByteArray, messageHash: ByteArray): Triple<BigInteger, BigInteger, Long> {
        val d = BigInteger(1, privKey)
        val n = ecSpec.n
        val e = BigInteger(1, messageHash)

        var k: BigInteger
        var r: BigInteger
        var s: BigInteger
        var v: Long

        val secureRandom = SecureRandom()
        do {
            do {
                k = BigInteger(256, secureRandom)
            } while (k.signum() == 0 || k >= n)

            val p = ecSpec.g.multiply(k).normalize()
            r = p.affineXCoord.toBigInteger().mod(n)
            val kInv = k.modInverse(n)
            s = kInv.multiply(e.add(d.multiply(r))).mod(n)
            v = if (p.affineYCoord.toBigInteger().testBit(0)) 1L else 0L
        } while (r.signum() == 0 || s.signum() == 0)

        // Canonical s (EIP-2)
        if (s > n.shiftRight(1)) {
            s = n.subtract(s)
            v = v xor 1L
        }

        return Triple(r, s, v)
    }

    data class BtcTxInput(val prevTxidInternalHex: String, val vout: Long, val sequence: Long)
    data class BtcTxOutput(val value: Long, val scriptPubKey: ByteArray)

    // BIP143 (SegWit v0) digest for SIGHASH_ALL. prevTxid must be in internal byte order (reverse of the displayed txid).
    fun bip143SighashAll(
        version: Long,
        inputs: List<BtcTxInput>,
        outputs: List<BtcTxOutput>,
        inputIndex: Int,
        scriptCode: ByteArray,
        amountSats: Long,
        locktime: Long
    ): ByteArray {
        val hashPrevouts = doubleSha256(concatBytes(inputs.map { hexToBytes(it.prevTxidInternalHex) + le32(it.vout) }))
        val hashSequence = doubleSha256(concatBytes(inputs.map { le32(it.sequence) }))
        val hashOutputs = doubleSha256(concatBytes(outputs.map { le64(it.value) + varInt(it.scriptPubKey.size) + it.scriptPubKey }))
        val input = inputs[inputIndex]
        val preimage = concatBytes(listOf(
            le32(version),
            hashPrevouts,
            hashSequence,
            hexToBytes(input.prevTxidInternalHex),
            le32(input.vout),
            varInt(scriptCode.size),
            scriptCode,
            le64(amountSats),
            le32(input.sequence),
            hashOutputs,
            le32(locktime),
            le32(1L)
        ))
        return doubleSha256(preimage)
    }

    // Signs one P2WPKH input. Returns DER signature + SIGHASH_ALL byte (hex) for the witness stack.
    fun signBip143P2wpkhInput(
        privKey: ByteArray,
        version: Long,
        inputs: List<BtcTxInput>,
        outputs: List<BtcTxOutput>,
        inputIndex: Int,
        amountSats: Long,
        locktime: Long
    ): String {
        val pubKeyHash = ripemd160(sha256(getPublicKey(privKey, true)))
        val scriptCode = byteArrayOf(0x76.toByte(), 0xa9.toByte(), 0x14.toByte()) + pubKeyHash + byteArrayOf(0x88.toByte(), 0xac.toByte())
        val digest = bip143SighashAll(version, inputs, outputs, inputIndex, scriptCode, amountSats, locktime)
        val (r, s, _) = signECDSA(privKey, digest)
        return bytesToHex(encodeDERSignature(r, s)) + "01"
    }

    data class BtcUtxo(val txidDisplayHex: String, val vout: Long, val amountSats: Long, val chain: Int, val index: Int)

    // Builds and signs a full SegWit (P2WPKH) transaction. Each input is signed with the key at its own
    // BIP84 path (chain/index). Change goes to the given change index, never to an address already used.
    fun buildSignedP2wpkhTx(
        seed: ByteArray,
        utxos: List<BtcUtxo>,
        toAddress: String,
        sendSats: Long,
        feeSats: Long,
        changeIndex: Int
    ): String {
        require(utxos.isNotEmpty()) { "No UTXOs provided" }
        require(sendSats >= DUST_LIMIT_SATS) { "Amount is below dust limit" }
        require(feeSats >= 0) { "Fee cannot be negative" }
        val totalIn = utxos.sumOf { it.amountSats }
        require(totalIn >= sendSats + feeSats) { "Insufficient funds: have $totalIn sats, need ${sendSats + feeSats}" }

        val changeKey = deriveBip84Key(seed, BTC_CHANGE_CHAIN, changeIndex)
        val changeScript = byteArrayOf(0x00, 0x14) + ripemd160(sha256(getPublicKey(changeKey, true)))
        val destScript = addressToScriptPubKey(toAddress)

        val changeSats = totalIn - sendSats - feeSats
        val outputs = mutableListOf(BtcTxOutput(sendSats, destScript))
        if (changeSats >= DUST_LIMIT_SATS) outputs.add(BtcTxOutput(changeSats, changeScript))

        val inputs = utxos.map {
            BtcTxInput(
                prevTxidInternalHex = bytesToHex(hexToBytes(it.txidDisplayHex).reversedArray()),
                vout = it.vout,
                sequence = RBF_SEQUENCE
            )
        }

        val signed = utxos.mapIndexed { i, u ->
            val key = deriveBip84Key(seed, u.chain, u.index)
            val sig = hexToBytes(signBip143P2wpkhInput(key, TX_VERSION, inputs, outputs, i, u.amountSats, TX_LOCKTIME))
            Pair(sig, getPublicKey(key, true))
        }

        val out = ByteArrayOutputStream()
        out.write(le32(TX_VERSION))
        out.write(byteArrayOf(0x00, 0x01))
        out.write(varInt(inputs.size))
        for (inp in inputs) {
            out.write(hexToBytes(inp.prevTxidInternalHex))
            out.write(le32(inp.vout))
            out.write(0x00)
            out.write(le32(inp.sequence))
        }
        out.write(varInt(outputs.size))
        for (o in outputs) {
            out.write(le64(o.value))
            out.write(varInt(o.scriptPubKey.size))
            out.write(o.scriptPubKey)
        }
        for ((sig, pub) in signed) {
            out.write(0x02)
            out.write(varInt(sig.size))
            out.write(sig)
            out.write(varInt(pub.size))
            out.write(pub)
        }
        out.write(le32(TX_LOCKTIME))
        return bytesToHex(out.toByteArray())
    }

    // Decodes a bech32 / bech32m-free native SegWit v0 address (bc1... or tb1...) into scriptPubKey bytes.
    fun addressToScriptPubKey(address: String): ByteArray {
        val charset = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
        val lower = address.lowercase()
        val pos = lower.lastIndexOf('1')
        require(pos > 0 && lower.length - pos - 1 >= 6) { "Invalid address format" }
        val hrp = lower.substring(0, pos)
        require(hrp == "bc" || hrp == "tb") { "Unsupported address prefix" }
        val data = lower.substring(pos + 1).map { c ->
            val idx = charset.indexOf(c)
            require(idx >= 0) { "Invalid address character" }
            idx
        }
        val expanded = hrp.map { it.code shr 5 } + listOf(0) + hrp.map { it.code and 31 }
        require(bech32Polymod(expanded + data) == 1) { "Invalid address checksum" }
        val payload = data.dropLast(6)
        require(payload.isNotEmpty() && payload[0] == 0) { "Only witness version 0 is supported" }
        val program = convertBits(payload.drop(1), 5, 8)
        require(program.size == 20) { "Only P2WPKH addresses are supported" }
        return byteArrayOf(0x00, 0x14) + program
    }

    private fun bech32Polymod(values: List<Int>): Int {
        val gen = intArrayOf(0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
        var chk = 1
        for (v in values) {
            val b = chk shr 25
            chk = ((chk and 0x1ffffff) shl 5) xor v
            for (i in 0 until 5) {
                if (((b shr i) and 1) != 0) chk = chk xor gen[i]
            }
        }
        return chk
    }

    private fun convertBits(data: List<Int>, from: Int, to: Int): ByteArray {
        var acc = 0
        var bits = 0
        val maxV = (1 shl to) - 1
        val out = ArrayList<Byte>()
        for (v in data) {
            acc = ((acc shl from) or v) and 0xFFFFFF
            bits += from
            while (bits >= to) {
                bits -= to
                out.add(((acc shr bits) and maxV).toByte())
            }
        }
        require(bits < from && ((acc shl (to - bits)) and maxV) == 0) { "Invalid padding in address" }
        return out.toByteArray()
    }

    private fun doubleSha256(data: ByteArray): ByteArray = sha256(sha256(data))

    private fun concatBytes(parts: List<ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        for (p in parts) out.write(p)
        return out.toByteArray()
    }

    private fun le32(v: Long): ByteArray = ByteArray(4) { i -> ((v shr (8 * i)) and 0xFFL).toByte() }

    private fun le64(v: Long): ByteArray = ByteArray(8) { i -> ((v shr (8 * i)) and 0xFFL).toByte() }

    private fun varInt(n: Int): ByteArray =
        if (n < 0xfd) byteArrayOf(n.toByte())
        else byteArrayOf(0xfd.toByte(), (n and 0xFF).toByte(), ((n shr 8) and 0xFF).toByte())

    private fun encodeDERSignature(r: BigInteger, s: BigInteger): ByteArray {
        val rBytes = r.toByteArray()
        val sBytes = s.toByteArray()
        val totalLen = 4 + rBytes.size + sBytes.size
        val out = ByteArrayOutputStream()
        out.write(0x30)
        out.write(totalLen)
        out.write(0x02)
        out.write(rBytes.size)
        out.write(rBytes)
        out.write(0x02)
        out.write(sBytes.size)
        out.write(sBytes)
        return out.toByteArray()
    }

    // Helper functions
    private fun getPublicKey(privKey: ByteArray, compressed: Boolean): ByteArray {
        val d = BigInteger(1, privKey)
        val q: ECPoint = ecSpec.g.multiply(d).normalize()
        return q.getEncoded(compressed)
    }

    private fun sha256(input: ByteArray): ByteArray {
        val digest = SHA256Digest()
        digest.update(input, 0, input.size)
        val out = ByteArray(32)
        digest.doFinal(out, 0)
        return out
    }

    private fun ripemd160(input: ByteArray): ByteArray {
        val digest = RIPEMD160Digest()
        digest.update(input, 0, input.size)
        val out = ByteArray(20)
        digest.doFinal(out, 0)
        return out
    }

    private fun pbkdf2HmacSha512(password: ByteArray, salt: ByteArray, iterations: Int, keyLength: Int): ByteArray {
        val hmac = HMac(SHA512Digest())
        hmac.init(KeyParameter(password))
        val output = ByteArray(keyLength)
        val numBlocks = (keyLength + 64 - 1) / 64
        var outPos = 0

        for (block in 1..numBlocks) {
            var u = ByteArray(64)
            val saltAndIndex = ByteArray(salt.size + 4)
            System.arraycopy(salt, 0, saltAndIndex, 0, salt.size)
            saltAndIndex[salt.size] = ((block shr 24) and 0xFF).toByte()
            saltAndIndex[salt.size + 1] = ((block shr 16) and 0xFF).toByte()
            saltAndIndex[salt.size + 2] = ((block shr 8) and 0xFF).toByte()
            saltAndIndex[salt.size + 3] = (block and 0xFF).toByte()

            hmac.update(saltAndIndex, 0, saltAndIndex.size)
            hmac.doFinal(u, 0)

            val blockResult = u.clone()
            for (iter in 2..iterations) {
                hmac.update(u, 0, u.size)
                hmac.doFinal(u, 0)
                for (j in 0 until 64) {
                    blockResult[j] = (blockResult[j].toInt() xor u[j].toInt()).toByte()
                }
            }

            val copyLen = Math.min(64, keyLength - outPos)
            System.arraycopy(blockResult, 0, output, outPos, copyLen)
            outPos += copyLen
        }
        return output
    }

    // RLP Encoding
    private fun encodeLong(v: Long): ByteArray {
        if (v == 0L) return ByteArray(0)
        return BigInteger.valueOf(v).toByteArray().filterIndexed { idx, byte -> !(idx == 0 && byte == 0.toByte()) }.toByteArray()
    }

    private fun encodeBigInt(v: BigInteger): ByteArray {
        if (v == BigInteger.ZERO) return ByteArray(0)
        val bytes = v.toByteArray()
        return if (bytes.isNotEmpty() && bytes[0] == 0.toByte()) bytes.copyOfRange(1, bytes.size) else bytes
    }

    private fun rlpEncodeList(items: List<ByteArray>): ByteArray {
        val body = ByteArrayOutputStream()
        for (item in items) {
            if (item.size == 1 && (item[0].toInt() and 0xFF) < 0x80) {
                body.write(item[0].toInt())
            } else if (item.size <= 55) {
                body.write(0x80 + item.size)
                body.write(item)
            } else {
                val lenBytes = encodeLong(item.size.toLong())
                body.write(0xb7 + lenBytes.size)
                body.write(lenBytes)
                body.write(item)
            }
        }
        val bodyBytes = body.toByteArray()
        val result = ByteArrayOutputStream()
        if (bodyBytes.size <= 55) {
            result.write(0xc0 + bodyBytes.size)
            result.write(bodyBytes)
        } else {
            val lenBytes = encodeLong(bodyBytes.size.toLong())
            result.write(0xf7 + lenBytes.size)
            result.write(lenBytes)
            result.write(bodyBytes)
        }
        return result.toByteArray()
    }

    // Bech32 native SegWit encoder
    private fun bech32Encode(hrp: String, witnessVersion: Int, program: ByteArray): String {
        val CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
        val converted = mutableListOf<Int>()
        converted.add(witnessVersion)

        var acc = 0
        var bits = 0
        for (b in program) {
            acc = (acc shl 8) or (b.toInt() and 0xFF)
            bits += 8
            while (bits >= 5) {
                bits -= 5
                converted.add((acc shr bits) and 31)
            }
        }
        if (bits > 0) {
            converted.add((acc shl (5 - bits)) and 31)
        }

        // Calculate checksum
        val values = mutableListOf<Int>()
        for (c in hrp) values.add(c.code shr 5)
        values.add(0)
        for (c in hrp) values.add(c.code and 31)
        values.addAll(converted)
        for (i in 0 until 6) values.add(0)

        var chk = 1
        val GEN = intArrayOf(0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
        for (v in values) {
            val b = chk shr 25
            chk = ((chk and 0x1ffffff) shl 5) xor v
            for (i in 0 until 5) {
                if (((b shr i) and 1) != 0) chk = chk xor GEN[i]
            }
        }
        val checksumPolymod = chk xor 1

        val checksum = mutableListOf<Int>()
        for (p in 0 until 6) {
            checksum.add((checksumPolymod shr (5 * (5 - p))) and 31)
        }

        val sb = StringBuilder(hrp).append("1")
        for (v in converted) sb.append(CHARSET[v])
        for (v in checksum) sb.append(CHARSET[v])
        return sb.toString()
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val hexChars = "0123456789abcdef"
        val result = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val i = b.toInt() and 0xFF
            result.append(hexChars[i shr 4])
            result.append(hexChars[i and 0x0F])
        }
        return result.toString()
    }

    private fun hexToBytes(hex: String): ByteArray {
        val len = hex.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(hex[i], 16) shl 4) + Character.digit(hex[i + 1], 16)).toByte()
            i += 2
        }
        return data
    }
}
