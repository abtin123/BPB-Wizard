import 'native_wallet_channel.dart';
import 'rpc_service.dart';

class BtcAddressInfo {
  final int chain;
  final int index;
  final String address;

  const BtcAddressInfo({required this.chain, required this.index, required this.address});
}

class BtcChainScan {
  final List<BtcAddressInfo> used;
  final BtcAddressInfo firstUnused;

  const BtcChainScan({required this.used, required this.firstUnused});
}

class BtcWalletSnapshot {
  final List<Map<String, dynamic>> utxos;
  final BtcAddressInfo nextReceive;
  final BtcAddressInfo changeAddress;

  const BtcWalletSnapshot({
    required this.utxos,
    required this.nextReceive,
    required this.changeAddress,
  });
}

/// Walks the receive and change chains with a gap limit, so we never hand out or change to an address that already has history.
class BtcAddressManager {
  static const int receiveChain = 0;
  static const int changeChain = 1;
  static const int gapLimit = 20;

  static Future<BtcChainScan> scanChain(int chain) async {
    final used = <BtcAddressInfo>[];
    BtcAddressInfo? firstUnused;
    int gap = 0;

    for (int index = 0; gap < gapLimit; index++) {
      final address = await NativeWalletChannel.getBitcoinAddress(chain: chain, index: index);
      final info = BtcAddressInfo(chain: chain, index: index, address: address);
      final txCount = await RpcService.fetchAddressTxCount(address);
      if (txCount > 0) {
        used.add(info);
        gap = 0;
      } else {
        firstUnused ??= info;
        gap++;
      }
    }

    return BtcChainScan(used: used, firstUnused: firstUnused!);
  }

  /// Scans both chains and collects spendable UTXOs from every used address.
  static Future<BtcWalletSnapshot> snapshot() async {
    final receive = await scanChain(receiveChain);
    final change = await scanChain(changeChain);

    final utxos = <Map<String, dynamic>>[];
    for (final scan in [receive, change]) {
      for (final addr in scan.used) {
        final list = await RpcService.fetchBtcUtxos(addr.address);
        for (final u in list) {
          utxos.add({...u, 'chain': addr.chain, 'index': addr.index});
        }
      }
    }

    return BtcWalletSnapshot(
      utxos: utxos,
      nextReceive: receive.firstUnused,
      changeAddress: change.firstUnused,
    );
  }
}
