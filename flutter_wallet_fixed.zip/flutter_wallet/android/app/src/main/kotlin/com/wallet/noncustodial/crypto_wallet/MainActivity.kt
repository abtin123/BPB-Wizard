package com.wallet.noncustodial.crypto_wallet

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.math.BigInteger

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.wallet.noncustodial/core"
    private lateinit var walletCore: WalletCore

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        walletCore = WalletCore(applicationContext)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "generateNewWallet" -> {
                    try {
                        val entropy = walletCore.generateEntropy()
                        walletCore.storeEncryptedEntropy(entropy)
                        val mnemonics = walletCore.entropyToMnemonic(entropy)
                        val seed = walletCore.mnemonicToSeed(mnemonics)
                        val ethPriv = walletCore.deriveEthereumPrivateKey(seed)
                        val btcPriv = walletCore.deriveBitcoinPrivateKey(seed)
                        val ethAddress = walletCore.getEthereumAddress(ethPriv)
                        val btcAddress = walletCore.getBitcoinSegwitAddress(btcPriv)

                        val resp = mapOf(
                            "mnemonic" to mnemonics,
                            "ethAddress" to ethAddress,
                            "btcAddress" to btcAddress
                        )
                        result.success(resp)
                    } catch (e: Exception) {
                        result.error("WALLET_GEN_ERROR", e.localizedMessage, null)
                    }
                }
                "getStoredAddresses" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                        if (entropy == null) {
                            result.success(null)
                            return@setMethodCallHandler
                        }
                        val mnemonics = walletCore.entropyToMnemonic(entropy)
                        val seed = walletCore.mnemonicToSeed(mnemonics)
                        val ethPriv = walletCore.deriveEthereumPrivateKey(seed)
                        val btcPriv = walletCore.deriveBitcoinPrivateKey(seed)
                        val ethAddress = walletCore.getEthereumAddress(ethPriv)
                        val btcAddress = walletCore.getBitcoinSegwitAddress(btcPriv)

                        val resp = mapOf(
                            "hasWallet" to true,
                            "ethAddress" to ethAddress,
                            "btcAddress" to btcAddress
                        )
                        result.success(resp)
                    } catch (e: Exception) {
                        result.error("KEYSTORE_LOAD_ERROR", e.localizedMessage, null)
                    }
                }
                "getMnemonicWords" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                        if (entropy == null) {
                            result.error("NO_WALLET", "No wallet stored in Android KeyStore", null)
                            return@setMethodCallHandler
                        }
                        val mnemonics = walletCore.entropyToMnemonic(entropy)
                        result.success(mnemonics)
                    } catch (e: Exception) {
                        result.error("MNEMONIC_EXPORT_ERROR", e.localizedMessage, null)
                    }
                }
                "signEthereumTx" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                            ?: throw IllegalStateException("Wallet not initialized")
                        val seed = walletCore.mnemonicToSeed(walletCore.entropyToMnemonic(entropy))
                        val ethPriv = walletCore.deriveEthereumPrivateKey(seed)

                        val nonce = (call.argument<Number>("nonce"))?.toLong() ?: 0L
                        val gasPrice = BigInteger(call.argument<String>("gasPrice") ?: "20000000000")
                        val gasLimit = BigInteger(call.argument<String>("gasLimit") ?: "21000")
                        val to = call.argument<String>("to") ?: ""
                        val value = BigInteger(call.argument<String>("value") ?: "0")
                        val data = (call.argument<String>("data") ?: "").toByteArray()
                        val chainId = (call.argument<Number>("chainId"))?.toLong() ?: 1L

                        val rawSignedTx = walletCore.signEthereumTransaction(
                            privKey = ethPriv,
                            nonce = nonce,
                            gasPrice = gasPrice,
                            gasLimit = gasLimit,
                            to = to,
                            value = value,
                            data = data,
                            chainId = chainId
                        )
                        result.success(rawSignedTx)
                    } catch (e: Exception) {
                        result.error("ETH_SIGN_ERROR", e.localizedMessage, null)
                    }
                }
                "signBitcoinTx" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                            ?: throw IllegalStateException("Wallet not initialized")
                        val seed = walletCore.mnemonicToSeed(walletCore.entropyToMnemonic(entropy))
                        val btcPriv = walletCore.deriveBitcoinPrivateKey(seed)

                        val txHex = call.argument<String>("txHex") ?: ""
                        val vout = (call.argument<Number>("vout"))?.toInt() ?: 0

                        val signatureHex = walletCore.signBitcoinTransaction(btcPriv, txHex, vout)
                        result.success(signatureHex)
                    } catch (e: Exception) {
                        result.error("BTC_SIGN_ERROR", e.localizedMessage, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
}
