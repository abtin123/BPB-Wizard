import 'dart:convert';
import 'package:http/http.dart' as http;

class RpcService {
  // Public Sepolia / Mainnet RPC endpoints
  static const String ethRpcUrl = 'https://ethereum-sepolia-rpc.publicnode.com';
  static const String btcApiUrl = 'https://blockstream.info/testnet/api';

  static Future<double> getEthBalance(String address) async {
    try {
      final response = await http.post(
        Uri.parse(ethRpcUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'jsonrpc': '2.0',
          'method': 'eth_getBalance',
          'params': [address, 'latest'],
          'id': 1,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['result'] != null) {
          final hexWei = data['result'] as String;
          final wei = BigInt.parse(hexWei.replaceFirst('0x', ''), radix: 16);
          return wei / BigInt.from(10).pow(18);
        }
      }
    } catch (_) {}
    return 0.0;
  }

  static Future<int> getEthNonce(String address) async {
    try {
      final response = await http.post(
        Uri.parse(ethRpcUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'jsonrpc': '2.0',
          'method': 'eth_getTransactionCount',
          'params': [address, 'latest'],
          'id': 1,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['result'] != null) {
          return int.parse((data['result'] as String).replaceFirst('0x', ''), radix: 16);
        }
      }
    } catch (_) {}
    return 0;
  }

  static Future<String> broadcastRawTransaction(String signedTxHex) async {
    try {
      final response = await http.post(
        Uri.parse(ethRpcUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'jsonrpc': '2.0',
          'method': 'eth_sendRawTransaction',
          'params': [signedTxHex],
          'id': 1,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['result'] != null) {
          return data['result'] as String;
        } else if (data['error'] != null) {
          throw Exception(data['error']['message']);
        }
      }
    } catch (e) {
      rethrow;
    }
    throw Exception('Failed to broadcast transaction');
  }

  static Future<double> getBtcBalance(String address) async {
    try {
      final response = await http.get(Uri.parse('$btcApiUrl/address/$address'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final chainStats = data['chain_stats'];
        final funded = chainStats['funded_txo_sum'] as int? ?? 0;
        final spent = chainStats['spent_txo_sum'] as int? ?? 0;
        final satoshis = funded - spent;
        return satoshis / 100000000.0;
      }
    } catch (_) {}
    return 0.0;
  }
}
