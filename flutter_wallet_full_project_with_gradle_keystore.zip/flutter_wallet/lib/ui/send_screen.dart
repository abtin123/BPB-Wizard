import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/wallet_provider.dart';
import '../services/btc_send_service.dart';
import 'scanner_screen.dart';

enum _Asset { eth, btc }

class SendScreen extends StatefulWidget {
  const SendScreen({super.key});

  @override
  State<SendScreen> createState() => _SendScreenState();
}

class _SendScreenState extends State<SendScreen> {
  final _recipientController = TextEditingController();
  final _amountController = TextEditingController();
  _Asset _asset = _Asset.eth;
  bool _busy = false;
  String? _feeQuote;

  @override
  void dispose() {
    _recipientController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  /// Parses a BTC amount string into satoshis using integer math only (no double).
  /// Returns null for invalid input or more than 8 decimal places.
  int? _parseBtcToSats(String text) {
    final match = RegExp(r'^(\d+)(?:\.(\d{1,8}))?$').firstMatch(text.trim());
    if (match == null) return null;
    final whole = int.parse(match.group(1)!);
    final fracRaw = match.group(2) ?? '';
    final frac = int.parse(fracRaw.padRight(8, '0'));
    final sats = whole * 100000000 + frac;
    if (sats <= 0) return null;
    return sats;
  }

  Future<void> _scanQrCode() async {
    final scanned = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const ScannerScreen()),
    );
    if (scanned != null && scanned.isNotEmpty) {
      setState(() {
        _recipientController.text = scanned.replaceFirst(RegExp(r'^(ethereum|bitcoin):'), '');
        _feeQuote = null;
      });
    }
  }

  Future<void> _quoteBtcFee() async {
    final sats = _parseBtcToSats(_amountController.text);
    if (sats == null) {
      _snack('مبلغ معتبر وارد کنید');
      return;
    }
    setState(() {
      _busy = true;
      _feeQuote = null;
    });
    try {
      final plan = await BtcSendService.planSend(sendSats: sats);
      if (!mounted) return;
      setState(() {
        _feeQuote = 'کارمزد تخمینی: ${plan.feeSats} ساتوشی | ورودی‌ها: ${plan.utxos.length} | باقیمانده: ${plan.changeSats} ساتوشی';
      });
    } catch (e) {
      _snack('خطا در برآورد کارمزد: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _sendBtc() async {
    final to = _recipientController.text.trim();
    final sats = _parseBtcToSats(_amountController.text);
    if (to.isEmpty || sats == null) {
      _snack('آدرس و مبلغ معتبر وارد کنید');
      return;
    }
    setState(() => _busy = true);
    try {
      final txid = await BtcSendService.sendBitcoin(toAddress: to, sendSats: sats);
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('تراکنش ارسال شد'),
          content: SelectableText('شناسه تراکنش:\n$txid'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('تأیید')),
          ],
        ),
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      _snack('خطا در ارسال: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _sendEth() async {
    final recipient = _recipientController.text.trim();
    final amount = double.tryParse(_amountController.text.trim()) ?? 0.0;
    if (recipient.isEmpty || amount <= 0) {
      _snack('لطفاً آدرس معتبر و مبلغ را وارد کنید');
      return;
    }
    setState(() => _busy = true);
    final wallet = context.read<WalletProvider>();
    try {
      final txHash = await wallet.sendEthereumTransaction(recipient: recipient, amountEth: amount);
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('تراکنش با موفقیت ارسال شد'),
          content: SelectableText('شناسه تراکنش (Tx Hash):\n$txHash'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('تأیید')),
          ],
        ),
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      _snack('خطا در ارسال: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isBtc = _asset == _Asset.btc;
    return Scaffold(
      appBar: AppBar(title: Text(isBtc ? 'ارسال بیت‌کوین' : 'ارسال اتریوم')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            SegmentedButton<_Asset>(
              segments: const [
                ButtonSegment(value: _Asset.eth, label: Text('ETH')),
                ButtonSegment(value: _Asset.btc, label: Text('BTC')),
              ],
              selected: {_asset},
              onSelectionChanged: (selection) => setState(() {
                _asset = selection.first;
                _feeQuote = null;
              }),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _recipientController,
              decoration: InputDecoration(
                labelText: isBtc ? 'آدرس مقصد (bc1 / tb1)' : 'آدرس مقصد (0x...)',
                filled: true,
                fillColor: const Color(0xFF191D2C),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.qr_code_scanner),
                  tooltip: 'اسکن کد QR',
                  onPressed: _scanQrCode,
                ),
              ),
            ),
            const SizedBox(height: 18),
            TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              onChanged: (_) => setState(() => _feeQuote = null),
              decoration: InputDecoration(
                labelText: isBtc ? 'مبلغ (BTC)' : 'مبلغ (ETH)',
                filled: true,
                fillColor: const Color(0xFF191D2C),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
            if (isBtc && _feeQuote != null) ...[
              const SizedBox(height: 14),
              Text(_feeQuote!, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
            const SizedBox(height: 28),
            if (isBtc) ...[
              SizedBox(
                width: double.infinity,
                height: 48,
                child: OutlinedButton(
                  onPressed: _busy ? null : _quoteBtcFee,
                  child: const Text('برآورد کارمزد'),
                ),
              ),
              const SizedBox(height: 12),
            ],
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6C5CE7),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: _busy ? null : (isBtc ? _sendBtc : _sendEth),
                child: _busy
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                      )
                    : Text(
                        isBtc ? 'امضای آفلاین و انتشار در شبکه' : 'امضای آفلاین و انتشار در شبکه',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
