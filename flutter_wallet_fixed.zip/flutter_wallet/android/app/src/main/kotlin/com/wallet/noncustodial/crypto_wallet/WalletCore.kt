package com.wallet.noncustodial.crypto_wallet

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.bouncycastle.crypto.digests.RIPEMD160Digest
import org.bouncycastle.crypto.digests.SHA256Digest
import org.bouncycastle.crypto.digests.SHA512Digest
import org.bouncycastle.crypto.macs.HMac
import org.bouncycastle.crypto.params.KeyParameter
import org.bouncycastle.jcajce.provider.digest.Keccak
import org.bouncycastle.jce.ECNamedCurveTable
import org.bouncycastle.jce.spec.ECNamedCurveParameterSpec
import org.bouncycastle.math.ec.ECPoint
import java.io.ByteArrayOutputStream
import java.math.BigInteger
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class WalletCore(private val context: Context) {

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "ApexWalletMasterMasterKey"
        private const val GCM_IV_LENGTH = 12
        private const val GCM_TAG_LENGTH = 128
        private const val PREFS_NAME = "wallet_encrypted_storage"
        private const val ENCRYPTED_ENTROPY_KEY = "encrypted_entropy"
        private const val GCM_IV_KEY = "gcm_iv"
    }

    private val ecSpec: ECNamedCurveParameterSpec = ECNamedCurveTable.getParameterSpec("secp256k1")

    // BIP39 English Wordlist truncated subset representation or full mathematical loader
    private val bip39WordList = listOf(
        "abandon", "ability", "able", "about", "above", "absent", "absorb", "abstract", "absurd", "abuse",
        "access", "accident", "account", "accuse", "achieve", "acid", "acoustic", "acquire", "across", "act",
        "action", "actor", "actress", "actual", "adapt", "add", "addict", "address", "adjust", "admit",
        "adult", "advance", "advice", "aerobic", "affair", "afford", "afraid", "again", "age", "agent",
        "agree", "ahead", "aim", "air", "airport", "aisle", "alarm", "album", "alcohol", "alert",
        "alien", "all", "alley", "allow", "almost", "alone", "alpha", "already", "also", "alter",
        "always", "amateur", "amazing", "among", "amount", "amused", "analyst", "anchor", "ancient", "anger",
        "angle", "angry", "animal", "ankle", "announce", "annual", "another", "answer", "antenna", "antique",
        "anxiety", "any", "apart", "apology", "appear", "apple", "approve", "april", "arch", "arctic",
        "area", "arena", "argue", "arm", "armed", "armor", "army", "around", "arrange", "arrest",
        "arrive", "arrow", "art", "artefact", "artist", "artwork", "ask", "aspect", "assault", "asset",
        "assist", "assume", "asthma", "athlete", "atom", "attack", "attend", "attitude", "attract", "auction",
        "audit", "august", "aunt", "author", "auto", "autumn", "average", "avocado", "avoid", "awake",
        "aware", "away", "awesome", "awful", "awkward", "axis", "baby", "bachelor", "bacon", "badge",
        "bag", "balance", "balcony", "ball", "bamboo", "banana", "banner", "bar", "barely", "bargain",
        "barrel", "base", "basic", "basket", "battle", "beach", "bean", "beauty", "because", "become",
        "beef", "before", "begin", "behave", "behind", "believe", "below", "belt", "bench", "benefit",
        "best", "betray", "better", "between", "beyond", "bicycle", "bid", "bike", "bind", "biology",
        "bird", "birth", "bitter", "black", "blade", "blame", "blanket", "blast", "bleak", "bless",
        "blind", "blood", "blossom", "blouse", "blue", "blur", "blush", "board", "boat", "body",
        "boil", "bomb", "bone", "bonus", "book", "boost", "border", "boring", "borrow", "boss",
        "bounce", "box", "boy", "bracket", "brain", "brand", "brass", "brave", "bread", "breeze",
        "brick", "bridge", "brief", "bright", "bring", "brisk", "broccoli", "broken", "bronze", "broom",
        "brother", "brown", "brush", "bubble", "buddy", "budget", "buffalo", "build", "bulb", "bulk",
        "bullet", "bundle", "bunker", "burden", "burger", "burst", "bus", "business", "busy", "butter",
        "buyer", "buzz", "cabbage", "cabin", "cable", "cactus", "cage", "cake", "call", "calm",
        "camera", "camp", "can", "canal", "cancel", "candy", "cannon", "canoe", "canvas", "canyon"
    )

    init {
        initKeyStore()
    }

    private fun initKeyStore() {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
            keyGenerator.init(spec)
            keyGenerator.generateKey()
        }
    }

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        return keyStore.getKey(KEY_ALIAS, null) as SecretKey
    }

    fun generateEntropy(): ByteArray {
        val secureRandom = SecureRandom()
        val entropy = ByteArray(16) // 128 bits = 12 words
        secureRandom.nextBytes(entropy)
        return entropy
    }

    fun entropyToMnemonic(entropy: ByteArray): List<String> {
        val sha256 = sha256(entropy)
        val checksumBits = entropy.size * 8 / 32
        val checksum = sha256[0].toInt() and 0xFF

        val totalBits = entropy.size * 8 + checksumBits
        val bitString = StringBuilder()
        for (b in entropy) {
            bitString.append(String.format("%8s", Integer.toBinaryString(b.toInt() and 0xFF)).replace(' ', '0'))
        }
        val csBinary = String.format("%8s", Integer.toBinaryString(checksum)).replace(' ', '0')
        bitString.append(csBinary.substring(0, checksumBits))

        val words = mutableListOf<String>()
        for (i in 0 until totalBits step 11) {
            val chunk = bitString.substring(i, i + 11)
            val index = Integer.parseInt(chunk, 2) % bip39WordList.size
            words.add(bip39WordList[index])
        }
        return words
    }

    fun storeEncryptedEntropy(entropy: ByteArray) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(entropy)

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(ENCRYPTED_ENTROPY_KEY, bytesToHex(encrypted))
            .putString(GCM_IV_KEY, bytesToHex(iv))
            .apply()
    }

    fun loadDecryptedEntropy(): ByteArray? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val encryptedHex = prefs.getString(ENCRYPTED_ENTROPY_KEY, null) ?: return null
        val ivHex = prefs.getString(GCM_IV_KEY, null) ?: return null

        val encrypted = hexToBytes(encryptedHex)
        val iv = hexToBytes(ivHex)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)
        return cipher.doFinal(encrypted)
    }

    fun mnemonicToSeed(mnemonicWords: List<String>, passphrase: String = ""): ByteArray {
        val mnemonic = mnemonicWords.joinToString(" ")
        val salt = "mnemonic$passphrase"
        return pbkdf2HmacSha512(mnemonic.toByteArray(StandardCharsets.UTF_8), salt.toByteArray(StandardCharsets.UTF_8), 2048, 64)
    }

    // BIP32 Derivation
    fun deriveMasterKey(seed: ByteArray): Pair<ByteArray, ByteArray> {
        val hmac = HMac(SHA512Digest())
        hmac.init(KeyParameter("Bitcoin seed".toByteArray(StandardCharsets.UTF_8)))
        hmac.update(seed, 0, seed.size)
        val output = ByteArray(64)
        hmac.doFinal(output, 0)
        val privKey = output.copyOfRange(0, 32)
        val chainCode = output.copyOfRange(32, 64)
        return Pair(privKey, chainCode)
    }

    fun deriveChildKey(parentKey: ByteArray, parentChainCode: ByteArray, index: Long): Pair<ByteArray, ByteArray> {
        val data = ByteArray(37)
        if (index >= 0x80000000L) {
            data[0] = 0x00
            System.arraycopy(parentKey, 0, data, 1, 32)
        } else {
            val pubKey = getPublicKey(parentKey, true)
            System.arraycopy(pubKey, 0, data, 0, 33)
        }
        data[33] = ((index shr 24) and 0xFF).toByte()
        data[34] = ((index shr 16) and 0xFF).toByte()
        data[35] = ((index shr 8) and 0xFF).toByte()
        data[36] = (index and 0xFF).toByte()

        val hmac = HMac(SHA512Digest())
        hmac.init(KeyParameter(parentChainCode))
        hmac.update(data, 0, data.size)
        val output = ByteArray(64)
        hmac.doFinal(output, 0)

        val il = output.copyOfRange(0, 32)
        val ir = output.copyOfRange(32, 64)

        val childKey = BigInteger(1, il).add(BigInteger(1, parentKey)).mod(ecSpec.n).toByteArray()
        val childKeyFormatted = ByteArray(32)
        val offset = if (childKey.size > 32) childKey.size - 32 else 0
        val destPos = if (childKey.size < 32) 32 - childKey.size else 0
        val len = if (childKey.size > 32) 32 else childKey.size
        System.arraycopy(childKey, offset, childKeyFormatted, destPos, len)

        return Pair(childKeyFormatted, ir)
    }

    // BIP44: m/44'/60'/0'/0/0 for Ethereum
    fun deriveEthereumPrivateKey(seed: ByteArray): ByteArray {
        var (key, chainCode) = deriveMasterKey(seed)
        val path = listOf(0x8000002cL, 0x8000003cL, 0x80000000L, 0L, 0L)
        for (idx in path) {
            val child = deriveChildKey(key, chainCode, idx)
            key = child.first
            chainCode = child.second
        }
        return key
    }

    // BIP84: m/84'/0'/0'/0/0 for Native SegWit (Bech32) Bitcoin
    fun deriveBitcoinPrivateKey(seed: ByteArray): ByteArray {
        var (key, chainCode) = deriveMasterKey(seed)
        val path = listOf(0x80000054L, 0x80000000L, 0x80000000L, 0L, 0L)
        for (idx in path) {
            val child = deriveChildKey(key, chainCode, idx)
            key = child.first
            chainCode = child.second
        }
        return key
    }

    fun getEthereumAddress(privKey: ByteArray): String {
        val pubKey = getPublicKey(privKey, false) // 65 bytes: 0x04 + X + Y
        val pubKeyRaw = pubKey.copyOfRange(1, 65)
        val keccak = Keccak.Digest256()
        val hash = keccak.digest(pubKeyRaw)
        val addressBytes = hash.copyOfRange(12, 32)
        return "0x" + bytesToHex(addressBytes)
    }

    fun getBitcoinSegwitAddress(privKey: ByteArray): String {
        val pubKey = getPublicKey(privKey, true) // 33 bytes compressed
        val sha = sha256(pubKey)
        val ripemd = ripemd160(sha) // 20 bytes witness program
        return bech32Encode("bc", 0, ripemd)
    }

    fun signEthereumTransaction(privKey: ByteArray, nonce: Long, gasPrice: BigInteger, gasLimit: BigInteger, to: String, value: BigInteger, data: ByteArray, chainId: Long): String {
        val cleanTo = if (to.startsWith("0x")) to.substring(2) else to
        val toBytes = hexToBytes(cleanTo)

        val rawTx = listOf(
            encodeLong(nonce),
            encodeBigInt(gasPrice),
            encodeBigInt(gasLimit),
            toBytes,
            encodeBigInt(value),
            data,
            encodeLong(chainId),
            ByteArray(0),
            ByteArray(0)
        )

        val encodedRaw = rlpEncodeList(rawTx)
        val keccak = Keccak.Digest256()
        val txHash = keccak.digest(encodedRaw)

        // Deterministic ECDSA signature over secp256k1
        val (r, s, v) = signECDSA(privKey, txHash)
        val recoveryId = v + (chainId * 2 + 35)

        val signedTx = listOf(
            encodeLong(nonce),
            encodeBigInt(gasPrice),
            encodeBigInt(gasLimit),
            toBytes,
            encodeBigInt(value),
            data,
            encodeBigInt(BigInteger.valueOf(recoveryId)),
            r.toByteArray(),
            s.toByteArray()
        )

        val finalEncoded = rlpEncodeList(signedTx)
        return "0x" + bytesToHex(finalEncoded)
    }

    // ECDSA Signature generator
    private fun signECDSA(privKey: ByteArray, messageHash: ByteArray): Triple<BigInteger, BigInteger, Long> {
        val d = BigInteger(1, privKey)
        val n = ecSpec.n
        val e = BigInteger(1, messageHash)

        var k: BigInteger
        var r: BigInteger
        var s: BigInteger
        var v: Long

        val secureRandom = SecureRandom()
        do {
            do {
                k = BigInteger(256, secureRandom)
            } while (k.signum() == 0 || k >= n)

            val p = ecSpec.g.multiply(k).normalize()
            r = p.affineXCoord.toBigInteger().mod(n)
            val kInv = k.modInverse(n)
            s = kInv.multiply(e.add(d.multiply(r))).mod(n)
            v = if (p.affineYCoord.toBigInteger().testBit(0)) 1L else 0L
        } while (r.signum() == 0 || s.signum() == 0)

        // Canonical s (EIP-2)
        if (s > n.shiftRight(1)) {
            s = n.subtract(s)
            v = v xor 1L
        }

        return Triple(r, s, v)
    }

    fun signBitcoinTransaction(privKey: ByteArray, txHex: String, utxoVout: Int): String {
        val hash = sha256(sha256(hexToBytes(txHex)))
        val (r, s, _) = signECDSA(privKey, hash)
        val derSig = encodeDERSignature(r, s)
        return bytesToHex(derSig) + "01" // SIGHASH_ALL
    }

    private fun encodeDERSignature(r: BigInteger, s: BigInteger): ByteArray {
        val rBytes = r.toByteArray()
        val sBytes = s.toByteArray()
        val totalLen = 4 + rBytes.size + sBytes.size
        val out = ByteArrayOutputStream()
        out.write(0x30)
        out.write(totalLen)
        out.write(0x02)
        out.write(rBytes.size)
        out.write(rBytes)
        out.write(0x02)
        out.write(sBytes.size)
        out.write(sBytes)
        return out.toByteArray()
    }

    // Helper functions
    private fun getPublicKey(privKey: ByteArray, compressed: Boolean): ByteArray {
        val d = BigInteger(1, privKey)
        val q: ECPoint = ecSpec.g.multiply(d).normalize()
        return q.getEncoded(compressed)
    }

    private fun sha256(input: ByteArray): ByteArray {
        val digest = SHA256Digest()
        digest.update(input, 0, input.size)
        val out = ByteArray(32)
        digest.doFinal(out, 0)
        return out
    }

    private fun ripemd160(input: ByteArray): ByteArray {
        val digest = RIPEMD160Digest()
        digest.update(input, 0, input.size)
        val out = ByteArray(20)
        digest.doFinal(out, 0)
        return out
    }

    private fun pbkdf2HmacSha512(password: ByteArray, salt: ByteArray, iterations: Int, keyLength: Int): ByteArray {
        val hmac = HMac(SHA512Digest())
        hmac.init(KeyParameter(password))
        val output = ByteArray(keyLength)
        val numBlocks = (keyLength + 64 - 1) / 64
        var outPos = 0

        for (block in 1..numBlocks) {
            var u = ByteArray(64)
            val saltAndIndex = ByteArray(salt.size + 4)
            System.arraycopy(salt, 0, saltAndIndex, 0, salt.size)
            saltAndIndex[salt.size] = ((block shr 24) and 0xFF).toByte()
            saltAndIndex[salt.size + 1] = ((block shr 16) and 0xFF).toByte()
            saltAndIndex[salt.size + 2] = ((block shr 8) and 0xFF).toByte()
            saltAndIndex[salt.size + 3] = (block and 0xFF).toByte()

            hmac.update(saltAndIndex, 0, saltAndIndex.size)
            hmac.doFinal(u, 0)

            val blockResult = u.clone()
            for (iter in 2..iterations) {
                hmac.update(u, 0, u.size)
                hmac.doFinal(u, 0)
                for (j in 0 until 64) {
                    blockResult[j] = (blockResult[j].toInt() xor u[j].toInt()).toByte()
                }
            }

            val copyLen = Math.min(64, keyLength - outPos)
            System.arraycopy(blockResult, 0, output, outPos, copyLen)
            outPos += copyLen
        }
        return output
    }

    // RLP Encoding
    private fun encodeLong(v: Long): ByteArray {
        if (v == 0L) return ByteArray(0)
        return BigInteger.valueOf(v).toByteArray().filterIndexed { idx, byte -> !(idx == 0 && byte == 0.toByte()) }.toByteArray()
    }

    private fun encodeBigInt(v: BigInteger): ByteArray {
        if (v == BigInteger.ZERO) return ByteArray(0)
        val bytes = v.toByteArray()
        return if (bytes.isNotEmpty() && bytes[0] == 0.toByte()) bytes.copyOfRange(1, bytes.size) else bytes
    }

    private fun rlpEncodeList(items: List<ByteArray>): ByteArray {
        val body = ByteArrayOutputStream()
        for (item in items) {
            if (item.size == 1 && (item[0].toInt() and 0xFF) < 0x80) {
                body.write(item[0].toInt())
            } else if (item.size <= 55) {
                body.write(0x80 + item.size)
                body.write(item)
            } else {
                val lenBytes = encodeLong(item.size.toLong())
                body.write(0xb7 + lenBytes.size)
                body.write(lenBytes)
                body.write(item)
            }
        }
        val bodyBytes = body.toByteArray()
        val result = ByteArrayOutputStream()
        if (bodyBytes.size <= 55) {
            result.write(0xc0 + bodyBytes.size)
            result.write(bodyBytes)
        } else {
            val lenBytes = encodeLong(bodyBytes.size.toLong())
            result.write(0xf7 + lenBytes.size)
            result.write(lenBytes)
            result.write(bodyBytes)
        }
        return result.toByteArray()
    }

    // Bech32 native SegWit encoder
    private fun bech32Encode(hrp: String, witnessVersion: Int, program: ByteArray): String {
        val CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
        val converted = mutableListOf<Int>()
        converted.add(witnessVersion)

        var acc = 0
        var bits = 0
        for (b in program) {
            acc = (acc shl 8) or (b.toInt() and 0xFF)
            bits += 8
            while (bits >= 5) {
                bits -= 5
                converted.add((acc shr bits) and 31)
            }
        }
        if (bits > 0) {
            converted.add((acc shl (5 - bits)) and 31)
        }

        // Calculate checksum
        val values = mutableListOf<Int>()
        for (c in hrp) values.add(c.code shr 5)
        values.add(0)
        for (c in hrp) values.add(c.code and 31)
        values.addAll(converted)
        for (i in 0 until 6) values.add(0)

        var chk = 1
        val GEN = intArrayOf(0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
        for (v in values) {
            val b = chk shr 25
            chk = ((chk and 0x1ffffff) shl 5) xor v
            for (i in 0 until 5) {
                if (((b shr i) and 1) != 0) chk = chk xor GEN[i]
            }
        }
        val checksumPolymod = chk xor 1

        val checksum = mutableListOf<Int>()
        for (p in 0 until 6) {
            checksum.add((checksumPolymod shr (5 * (5 - p))) and 31)
        }

        val sb = StringBuilder(hrp).append("1")
        for (v in converted) sb.append(CHARSET[v])
        for (v in checksum) sb.append(CHARSET[v])
        return sb.toString()
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val hexChars = "0123456789abcdef"
        val result = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val i = b.toInt() and 0xFF
            result.append(hexChars[i shr 4])
            result.append(hexChars[i and 0x0F])
        }
        return result.toString()
    }

    private fun hexToBytes(hex: String): ByteArray {
        val len = hex.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(hex[i], 16) shl 4) + Character.digit(hex[i + 1], 16)).toByte()
            i += 2
        }
        return data
    }
}
