import 'btc_address_manager.dart';
import 'native_wallet_channel.dart';
import 'rpc_service.dart';

/// Result of coin selection and fee estimation for a Bitcoin send.
class BtcSendPlan {
  final List<Map<String, dynamic>> utxos;
  final int totalInputSats;
  final int sendSats;
  final int feeSats;
  final int changeSats;
  final int changeIndex;

  const BtcSendPlan({
    required this.utxos,
    required this.totalInputSats,
    required this.sendSats,
    required this.feeSats,
    required this.changeSats,
    required this.changeIndex,
  });
}

class BtcSendService {
  static const int dustLimitSats = 546;

  /// P2WPKH vsize estimate: ~10.5 bytes overhead, 68 vB per input, 31 vB per output.
  static int estimateVsize({required int inputCount, required int outputCount}) {
    return (10.5 + 68 * inputCount + 31 * outputCount).ceil();
  }

  static int estimateFeeSats({
    required int inputCount,
    required int outputCount,
    required double feeRateSatPerVb,
  }) {
    return (estimateVsize(inputCount: inputCount, outputCount: outputCount) * feeRateSatPerVb).ceil();
  }

  /// Picks confirmed UTXOs (largest first) until they cover the amount plus the estimated fee.
  /// Change goes to the first never-used change address.
  static Future<BtcSendPlan> planSend({
    required int sendSats,
    int targetBlocks = 3,
  }) async {
    if (sendSats < dustLimitSats) {
      throw Exception('Amount is below the dust limit');
    }

    final snapshot = await BtcAddressManager.snapshot();
    final confirmed = snapshot.utxos.where((u) {
      final status = u['status'] as Map<String, dynamic>?;
      return status != null && status['confirmed'] == true;
    }).toList()
      ..sort((a, b) => (b['value'] as int).compareTo(a['value'] as int));

    final feeRate = await RpcService.fetchBtcFeeRate(targetBlocks);

    final selected = <Map<String, dynamic>>[];
    int total = 0;
    int fee = 0;
    for (final utxo in confirmed) {
      selected.add(utxo);
      total += utxo['value'] as int;
      fee = estimateFeeSats(inputCount: selected.length, outputCount: 2, feeRateSatPerVb: feeRate);
      if (total >= sendSats + fee) break;
    }

    if (total < sendSats + fee) {
      throw Exception('Insufficient confirmed balance for amount plus fee');
    }

    final change = total - sendSats - fee;
    return BtcSendPlan(
      utxos: selected,
      totalInputSats: total,
      sendSats: sendSats,
      feeSats: fee,
      changeSats: change >= dustLimitSats ? change : 0,
      changeIndex: snapshot.changeAddress.index,
    );
  }

  /// Builds, signs and broadcasts a P2WPKH transaction. Returns the txid.
  static Future<String> sendBitcoin({
    required String toAddress,
    required int sendSats,
    int targetBlocks = 3,
  }) async {
    final plan = await planSend(sendSats: sendSats, targetBlocks: targetBlocks);
    final utxos = plan.utxos
        .map((u) => {
              'txid': u['txid'],
              'vout': u['vout'],
              'amountSats': u['value'],
              'chain': u['chain'],
              'index': u['index'],
            })
        .toList();

    final rawTx = await NativeWalletChannel.buildBitcoinTx(
      utxos: utxos,
      toAddress: toAddress,
      sendSats: plan.sendSats,
      feeSats: plan.feeSats,
      changeIndex: plan.changeIndex,
    );
    return RpcService.broadcastBitcoinTransaction(rawTx);
  }
}
