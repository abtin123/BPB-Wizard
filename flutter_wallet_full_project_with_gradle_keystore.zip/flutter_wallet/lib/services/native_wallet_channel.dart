import 'package:flutter/services.dart';

class NativeWalletChannel {
  static const MethodChannel _channel = MethodChannel('com.wallet.noncustodial/core');

  static Future<Map<String, dynamic>> generateNewWallet() async {
    final result = await _channel.invokeMethod<Map<dynamic, dynamic>>('generateNewWallet');
    return Map<String, dynamic>.from(result ?? {});
  }

  static Future<Map<String, dynamic>?> getStoredAddresses() async {
    final result = await _channel.invokeMethod<Map<dynamic, dynamic>>('getStoredAddresses');
    if (result == null) return null;
    return Map<String, dynamic>.from(result);
  }

  static Future<List<String>> getMnemonicWords() async {
    final result = await _channel.invokeMethod<List<dynamic>>('getMnemonicWords');
    return result?.map((e) => e.toString()).toList() ?? [];
  }

  static Future<String> signEthereumTx({
    required int nonce,
    required String gasPriceWei,
    required String gasLimit,
    required String to,
    required String valueWei,
    required String data,
    required int chainId,
  }) async {
    final result = await _channel.invokeMethod<String>('signEthereumTx', {
      'nonce': nonce,
      'gasPrice': gasPriceWei,
      'gasLimit': gasLimit,
      'to': to,
      'value': valueWei,
      'data': data,
      'chainId': chainId,
    });
    return result ?? '';
  }

  /// Signs one P2WPKH input (BIP143, SIGHASH_ALL) using the key at the given path. Returns DER sig + sighash byte as hex.
  static Future<String> signBitcoinTx({
    required int version,
    required int locktime,
    required int inputIndex,
    required int amountSats,
    required List<Map<String, dynamic>> inputs,
    required List<Map<String, dynamic>> outputs,
  }) async {
    final result = await _channel.invokeMethod<String>('signBitcoinTx', {
      'version': version,
      'locktime': locktime,
      'inputIndex': inputIndex,
      'amountSats': amountSats,
      'inputs': inputs,
      'outputs': outputs,
    });
    return result ?? '';
  }

  /// Returns the native SegWit address for the BIP84 path m/84'/0'/0'/chain/index (chain 0 = receive, 1 = change).
  static Future<String> getBitcoinAddress({required int chain, required int index}) async {
    final result = await _channel.invokeMethod<String>('getBitcoinAddress', {
      'chain': chain,
      'index': index,
    });
    return result ?? '';
  }

  /// Builds, signs and serializes a full P2WPKH transaction in Kotlin. Returns raw tx hex.
  /// utxos: [{txid (display order hex), vout, amountSats, chain, index}]. changeIndex picks the change address.
  static Future<String> buildBitcoinTx({
    required List<Map<String, dynamic>> utxos,
    required String toAddress,
    required int sendSats,
    required int feeSats,
    required int changeIndex,
  }) async {
    final result = await _channel.invokeMethod<String>('buildBitcoinTx', {
      'utxos': utxos,
      'toAddress': toAddress,
      'sendSats': sendSats,
      'feeSats': feeSats,
      'changeIndex': changeIndex,
    });
    return result ?? '';
  }
}
