import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../providers/wallet_provider.dart';
import '../services/btc_address_manager.dart';

class ReceiveScreen extends StatefulWidget {
  const ReceiveScreen({super.key});

  @override
  State<ReceiveScreen> createState() => _ReceiveScreenState();
}

class _ReceiveScreenState extends State<ReceiveScreen> {
  late Future<BtcAddressInfo> _nextBtcReceive;

  @override
  void initState() {
    super.initState();
    _nextBtcReceive = _loadNextBtcReceive();
  }

  Future<BtcAddressInfo> _loadNextBtcReceive() async {
    final scan = await BtcAddressManager.scanChain(BtcAddressManager.receiveChain);
    return scan.firstUnused;
  }

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('دریافت رمزارز')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          _ReceiveCard(
            symbol: 'ETH',
            title: 'اتریوم (Sepolia / Mainnet)',
            address: wallet.ethAddress,
          ),
          const SizedBox(height: 24),
          FutureBuilder<BtcAddressInfo>(
            future: _nextBtcReceive,
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError || snapshot.data == null) {
                return const Text('خطا در دریافت آدرس بیت‌کوین. دوباره تلاش کنید.');
              }
              return _ReceiveCard(
                symbol: 'BTC',
                title: 'بیت‌کوین (Bech32 SegWit، آدرس تازه)',
                address: snapshot.data!.address,
              );
            },
          ),
        ],
      ),
    );
  }
}

class _ReceiveCard extends StatelessWidget {
  final String symbol;
  final String title;
  final String address;

  const _ReceiveCard({
    required this.symbol,
    required this.title,
    required this.address,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF191D2C),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
            child: QrImageView(
              data: address,
              version: QrVersions.auto,
              size: 180.0,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            address,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, color: Colors.white70, fontFamily: 'monospace'),
          ),
          const SizedBox(height: 12),
          TextButton.icon(
            icon: const Icon(Icons.copy, size: 18),
            label: const Text('کپی آدرس'),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: address));
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('آدرس $symbol کپی شد')),
              );
            },
          ),
        ],
      ),
    );
  }
}
