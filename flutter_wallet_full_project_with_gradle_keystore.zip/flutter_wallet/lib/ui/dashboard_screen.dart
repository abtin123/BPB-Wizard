import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/wallet_provider.dart';
import 'send_screen.dart';
import 'receive_screen.dart';
import 'mnemonic_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();

    if (wallet.isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(color: Color(0xFF6C5CE7)),
        ),
      );
    }

    if (!wallet.hasWallet) {
      return Scaffold(
        body: Container(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0F121C), Color(0xFF1E1435)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.shield_outlined, size: 90, color: Color(0xFF6C5CE7)),
              const SizedBox(height: 24),
              const Text(
                'کیف پول غیرامانی آبتین',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              const Text(
                'رمزنگاری سخت‌افزاری با Android KeyStore AES-256-GCM.\nکلیدهای خصوصی هرگز وارد محیط اجرای برنامه نمی‌شوند.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white60, fontSize: 14),
              ),
              const SizedBox(height: 48),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6C5CE7),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () async {
                  await wallet.createNewWallet();
                  if (context.mounted) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const MnemonicScreen()),
                    );
                  }
                },
                child: const Text('ساخت کیف پول جدید', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('صندوق امن آبتین', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'به‌روزرسانی موجودی',
            onPressed: () => wallet.refreshBalances(),
          ),
          IconButton(
            icon: const Icon(Icons.vpn_key_outlined),
            tooltip: 'کلمات بازیابی',
            onPressed: () {
              wallet.loadMnemonicWords();
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MnemonicScreen()),
              );
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => wallet.refreshBalances(),
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0x1A69F0AE),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0x4D69F0AE)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.lock_rounded, size: 16, color: Colors.greenAccent),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'امنیت سخت‌افزاری فعال: حفاظت‌شده در محیط ایزوله Keystore',
                      style: TextStyle(color: Colors.greenAccent, fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF6C5CE7), Color(0xFF3B28A8)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('مجموع دارایی‌های چند زنجیره‌ای', style: TextStyle(color: Colors.white70, fontSize: 13)),
                  const SizedBox(height: 10),
                  Text(
                    '${wallet.ethBalance.toStringAsFixed(4)} ETH',
                    style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${wallet.btcBalance.toStringAsFixed(6)} BTC',
                    style: const TextStyle(fontSize: 20, color: Color(0xFF00CEC9), fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF191D2C),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    icon: const Icon(Icons.arrow_upward, color: Color(0xFFFF7675)),
                    label: const Text('ارسال', style: TextStyle(fontWeight: FontWeight.bold)),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const SendScreen()));
                    },
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF191D2C),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    icon: const Icon(Icons.arrow_downward, color: Color(0xFF55EFC4)),
                    label: const Text('دریافت', style: TextStyle(fontWeight: FontWeight.bold)),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiveScreen()));
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 28),
            const Text('آدرس‌های تولید‌شده اختصاصی', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            _AddressCard(
              title: 'اتریوم (BIP44)',
              address: wallet.ethAddress,
              balance: '${wallet.ethBalance.toStringAsFixed(4)} ETH',
              iconColor: const Color(0xFF6C5CE7),
            ),
            const SizedBox(height: 12),
            _AddressCard(
              title: 'بیت‌کوین SegWit بومی (BIP84)',
              address: wallet.btcAddress,
              balance: '${wallet.btcBalance.toStringAsFixed(6)} BTC',
              iconColor: const Color(0xFFF39C12),
            ),
          ],
        ),
      ),
    );
  }
}

class _AddressCard extends StatelessWidget {
  final String title;
  final String address;
  final String balance;
  final Color iconColor;

  const _AddressCard({
    required this.title,
    required this.address,
    required this.balance,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF191D2C),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(backgroundColor: iconColor.withAlpha(51), radius: 14, child: Icon(Icons.token, size: 16, color: iconColor)),
              const SizedBox(width: 10),
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const Spacer(),
              Text(balance, style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Text(
                  address.isEmpty ? 'در حال استخراج...' : address,
                  style: const TextStyle(fontSize: 12, color: Colors.white60, fontFamily: 'monospace'),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.copy, size: 16, color: Colors.white70),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: address));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('آدرس $title کپی شد')),
                  );
                },
              )
            ],
          ),
        ],
      ),
    );
  }
}
