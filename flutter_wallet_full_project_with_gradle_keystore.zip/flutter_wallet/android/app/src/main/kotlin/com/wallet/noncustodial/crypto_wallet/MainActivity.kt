package com.wallet.noncustodial.crypto_wallet

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.math.BigInteger

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.wallet.noncustodial/core"
    private lateinit var walletCore: WalletCore

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        walletCore = WalletCore(applicationContext)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "generateNewWallet" -> {
                    try {
                        val entropy = walletCore.generateEntropy()
                        walletCore.storeEncryptedEntropy(entropy)
                        val mnemonics = walletCore.entropyToMnemonic(entropy)
                        val seed = walletCore.mnemonicToSeed(mnemonics)
                        val ethPriv = walletCore.deriveEthereumPrivateKey(seed)
                        val btcPriv = walletCore.deriveBitcoinPrivateKey(seed)
                        val ethAddress = walletCore.getEthereumAddress(ethPriv)
                        val btcAddress = walletCore.getBitcoinSegwitAddress(btcPriv)

                        val resp = mapOf(
                            "mnemonic" to mnemonics,
                            "ethAddress" to ethAddress,
                            "btcAddress" to btcAddress
                        )
                        result.success(resp)
                    } catch (e: Exception) {
                        result.error("WALLET_GEN_ERROR", e.localizedMessage, null)
                    }
                }
                "getStoredAddresses" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                        if (entropy == null) {
                            result.success(null)
                            return@setMethodCallHandler
                        }
                        val mnemonics = walletCore.entropyToMnemonic(entropy)
                        val seed = walletCore.mnemonicToSeed(mnemonics)
                        val ethPriv = walletCore.deriveEthereumPrivateKey(seed)
                        val btcPriv = walletCore.deriveBitcoinPrivateKey(seed)
                        val ethAddress = walletCore.getEthereumAddress(ethPriv)
                        val btcAddress = walletCore.getBitcoinSegwitAddress(btcPriv)

                        val resp = mapOf(
                            "hasWallet" to true,
                            "ethAddress" to ethAddress,
                            "btcAddress" to btcAddress
                        )
                        result.success(resp)
                    } catch (e: Exception) {
                        result.error("KEYSTORE_LOAD_ERROR", e.localizedMessage, null)
                    }
                }
                "getMnemonicWords" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                        if (entropy == null) {
                            result.error("NO_WALLET", "No wallet stored in Android KeyStore", null)
                            return@setMethodCallHandler
                        }
                        val mnemonics = walletCore.entropyToMnemonic(entropy)
                        result.success(mnemonics)
                    } catch (e: Exception) {
                        result.error("MNEMONIC_EXPORT_ERROR", e.localizedMessage, null)
                    }
                }
                "signEthereumTx" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                            ?: throw IllegalStateException("Wallet not initialized")
                        val seed = walletCore.mnemonicToSeed(walletCore.entropyToMnemonic(entropy))
                        val ethPriv = walletCore.deriveEthereumPrivateKey(seed)

                        val nonce = (call.argument<Number>("nonce"))?.toLong() ?: 0L
                        val gasPrice = BigInteger(call.argument<String>("gasPrice") ?: "20000000000")
                        val gasLimit = BigInteger(call.argument<String>("gasLimit") ?: "21000")
                        val to = call.argument<String>("to") ?: ""
                        val value = BigInteger(call.argument<String>("value") ?: "0")
                        val data = (call.argument<String>("data") ?: "").toByteArray()
                        val chainId = (call.argument<Number>("chainId"))?.toLong() ?: 1L

                        val rawSignedTx = walletCore.signEthereumTransaction(
                            privKey = ethPriv,
                            nonce = nonce,
                            gasPrice = gasPrice,
                            gasLimit = gasLimit,
                            to = to,
                            value = value,
                            data = data,
                            chainId = chainId
                        )
                        result.success(rawSignedTx)
                    } catch (e: Exception) {
                        result.error("ETH_SIGN_ERROR", e.localizedMessage, null)
                    }
                }
                "signBitcoinTx" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                            ?: throw IllegalStateException("Wallet not initialized")
                        val seed = walletCore.mnemonicToSeed(walletCore.entropyToMnemonic(entropy))
                        val btcPriv = walletCore.deriveBitcoinPrivateKey(seed)

                        val version = (call.argument<Number>("version"))?.toLong() ?: 2L
                        val locktime = (call.argument<Number>("locktime"))?.toLong() ?: 0L
                        val inputIndex = (call.argument<Number>("inputIndex"))?.toInt() ?: 0
                        val amountSats = (call.argument<Number>("amountSats"))?.toLong()
                            ?: throw IllegalArgumentException("amountSats required")

                        val rawInputs = call.argument<List<Map<String, Any>>>("inputs")
                            ?: throw IllegalArgumentException("inputs required")
                        val inputs = rawInputs.map {
                            WalletCore.BtcTxInput(
                                prevTxidInternalHex = it["txid"] as String,
                                vout = (it["vout"] as Number).toLong(),
                                sequence = (it["sequence"] as Number).toLong()
                            )
                        }

                        val rawOutputs = call.argument<List<Map<String, Any>>>("outputs")
                            ?: throw IllegalArgumentException("outputs required")
                        val outputs = rawOutputs.map {
                            WalletCore.BtcTxOutput(
                                value = (it["value"] as Number).toLong(),
                                scriptPubKey = hexToBytesSafe(it["scriptPubKey"] as String)
                            )
                        }

                        val signature = walletCore.signBip143P2wpkhInput(
                            privKey = btcPriv,
                            version = version,
                            inputs = inputs,
                            outputs = outputs,
                            inputIndex = inputIndex,
                            amountSats = amountSats,
                            locktime = locktime
                        )
                        result.success(signature)
                    } catch (e: Exception) {
                        result.error("BTC_SIGN_ERROR", e.localizedMessage, null)
                    }
                }
                "buildBitcoinTx" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                            ?: throw IllegalStateException("Wallet not initialized")
                        val seed = walletCore.mnemonicToSeed(walletCore.entropyToMnemonic(entropy))

                        val rawUtxos = call.argument<List<Map<String, Any>>>("utxos")
                            ?: throw IllegalArgumentException("utxos required")
                        val utxos = rawUtxos.map {
                            WalletCore.BtcUtxo(
                                txidDisplayHex = it["txid"] as String,
                                vout = (it["vout"] as Number).toLong(),
                                amountSats = (it["amountSats"] as Number).toLong(),
                                chain = (it["chain"] as Number).toInt(),
                                index = (it["index"] as Number).toInt()
                            )
                        }
                        val toAddress = call.argument<String>("toAddress")
                            ?: throw IllegalArgumentException("toAddress required")
                        val sendSats = (call.argument<Number>("sendSats"))?.toLong()
                            ?: throw IllegalArgumentException("sendSats required")
                        val feeSats = (call.argument<Number>("feeSats"))?.toLong() ?: 0L
                        val changeIndex = (call.argument<Number>("changeIndex"))?.toInt()
                            ?: throw IllegalArgumentException("changeIndex required")

                        val rawTx = walletCore.buildSignedP2wpkhTx(seed, utxos, toAddress, sendSats, feeSats, changeIndex)
                        result.success(rawTx)
                    } catch (e: Exception) {
                        result.error("BTC_TX_ERROR", e.localizedMessage, null)
                    }
                }
                "getBitcoinAddress" -> {
                    try {
                        val entropy = walletCore.loadDecryptedEntropy()
                            ?: throw IllegalStateException("Wallet not initialized")
                        val seed = walletCore.mnemonicToSeed(walletCore.entropyToMnemonic(entropy))
                        val chain = (call.argument<Number>("chain"))?.toInt() ?: 0
                        val index = (call.argument<Number>("index"))?.toInt() ?: 0
                        val key = walletCore.deriveBip84Key(seed, chain, index)
                        result.success(walletCore.bip84Address(key))
                    } catch (e: Exception) {
                        result.error("BTC_ADDRESS_ERROR", e.localizedMessage, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
}

private fun hexToBytesSafe(hex: String): ByteArray {
    val clean = if (hex.startsWith("0x")) hex.substring(2) else hex
    return ByteArray(clean.length / 2) { i ->
        ((Character.digit(clean[i * 2], 16) shl 4) + Character.digit(clean[i * 2 + 1], 16)).toByte()
    }
}
