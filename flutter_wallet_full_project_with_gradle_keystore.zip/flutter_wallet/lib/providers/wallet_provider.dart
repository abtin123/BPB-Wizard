import 'package:flutter/foundation.dart';
import '../services/native_wallet_channel.dart';
import '../services/btc_address_manager.dart';
import '../services/rpc_service.dart';

class WalletProvider extends ChangeNotifier {
  bool _isLoading = false;
  bool _hasWallet = false;
  String _ethAddress = '';
  String _btcAddress = '';
  double _ethBalance = 0.0;
  double _btcBalance = 0.0;
  List<String> _mnemonic = [];
  String _securityStatus = 'Secure Enclave / Android KeyStore Active';

  bool get isLoading => _isLoading;
  bool get hasWallet => _hasWallet;
  String get ethAddress => _ethAddress;
  String get btcAddress => _btcAddress;
  double get ethBalance => _ethBalance;
  double get btcBalance => _btcBalance;
  List<String> get mnemonic => _mnemonic;
  String get securityStatus => _securityStatus;

  Future<void> initialize() async {
    _isLoading = true;
    notifyListeners();

    try {
      final stored = await NativeWalletChannel.getStoredAddresses();
      if (stored != null && stored['hasWallet'] == true) {
        _hasWallet = true;
        _ethAddress = stored['ethAddress'] ?? '';
        _btcAddress = stored['btcAddress'] ?? '';
        await refreshBalances();
      }
    } catch (e) {
      debugPrint('Initialization error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> createNewWallet() async {
    _isLoading = true;
    notifyListeners();

    try {
      final res = await NativeWalletChannel.generateNewWallet();
      _hasWallet = true;
      _mnemonic = List<String>.from(res['mnemonic'] ?? []);
      _ethAddress = res['ethAddress'] ?? '';
      _btcAddress = res['btcAddress'] ?? '';
      await refreshBalances();
    } catch (e) {
      debugPrint('Wallet Creation error: $e');
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadMnemonicWords() async {
    try {
      _mnemonic = await NativeWalletChannel.getMnemonicWords();
      notifyListeners();
    } catch (e) {
      debugPrint('Failed to load mnemonic: $e');
    }
  }

  Future<void> refreshBalances() async {
    if (_ethAddress.isNotEmpty) {
      _ethBalance = await RpcService.getEthBalance(_ethAddress);
    }
    if (_btcAddress.isNotEmpty) {
      try {
        final snapshot = await BtcAddressManager.snapshot();
        final sats = snapshot.utxos.fold<int>(0, (sum, u) => sum + (u['value'] as int));
        _btcBalance = sats / 100000000.0;
      } catch (e) {
        debugPrint('BTC balance refresh failed: $e');
      }
    }
    notifyListeners();
  }

  Future<String> sendEthereumTransaction({
    required String recipient,
    required double amountEth,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final nonce = await RpcService.getEthNonce(_ethAddress);
      final valueWei = BigInt.from((amountEth * 1e18).round()).toString();
      const gasLimit = '21000';
      const gasPriceWei = '25000000000'; // 25 Gwei

      final signedRawTx = await NativeWalletChannel.signEthereumTx(
        nonce: nonce,
        gasPriceWei: gasPriceWei,
        gasLimit: gasLimit,
        to: recipient,
        valueWei: valueWei,
        data: '',
        chainId: 11155111, // Sepolia Testnet
      );

      final txHash = await RpcService.broadcastRawTransaction(signedRawTx);
      await refreshBalances();
      return txHash;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
