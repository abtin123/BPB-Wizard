import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/wallet_provider.dart';

class MnemonicScreen extends StatelessWidget {
  const MnemonicScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final words = context.watch<WalletProvider>().mnemonic;

    return Scaffold(
      appBar: AppBar(title: const Text('BIP39 Secret Recovery Phrase')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.amber.withOpacity(0.4)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: Colors.amber),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Never disclose these 12 words to anyone. Anyone with this phrase can steal your funds.',
                      style: TextStyle(color: Colors.amber, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: GridView.builder(
                gridDelegate: const QuadDelegate(),
                itemCount: words.length,
                itemBuilder: (ctx, idx) {
                  return Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF191D2C),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white12),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(
                      children: [
                        Text('${idx + 1}. ', style: const TextStyle(color: Colors.white38, fontSize: 13)),
                        Text(words[idx], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                      ],
                    ),
                  );
                },
              ),
            ),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6C5CE7),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              icon: const Icon(Icons.copy),
              label: const Text('Copy Mnemonic Phrase'),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: words.join(' ')));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Recovery phrase copied securely')),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class QuadDelegate extends SliverGridDelegate {
  const QuadDelegate();
  @override
  SliverGridLayout getLayout(SliverConstraints constraints) {
    return SliverGridRegularTileLayout(
      crossAxisCount: 3,
      mainAxisStride: 52,
      crossAxisStride: constraints.crossAxisExtent / 3,
      childMainAxisExtent: 44,
      childCrossAxisExtent: (constraints.crossAxisExtent / 3) - 8,
      reverseCrossAxis: false,
    );
  }
  @override
  bool shouldRelayout(covariant SliverGridDelegate oldDelegate) => false;
}
